
import sys
from PyQt5 import QtCore
from PyQt5 import QtGui
import aboutus
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QToolTip
from PyQt5.QtGui import QFont
from PyQt5.QtCore import QTimer
from PyQt5.QtCore import QEventLoop
from Main import Admin
from Main import Email
from Main import Purchase
from Main import Validation
from Main import Sales
from datetime import datetime


class UiDeleteAdmin(object):
    """This class has the window of
    delte admin"""

    def __init__(self):

        """This window is called when
        the class is called
         """
        #self.app = QtWidgets.QApplication(sys.argv)
        self.deleteadmin = QtWidgets.QDialog()
        UiDeleteAdmin.setupUi(self, self.deleteadmin)
        self.deleteadmin.show()
        #sys.exit(self.app.exec_())

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label.setStyleSheet("image: url(Images/bg.jpg)")
        self.label.setText("")
        self.label.setObjectName("label")
        self.groupBox = QtWidgets.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(240, 30, 461, 501))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet("QGroupBox{\n"
"background:rgb(197, 210, 255);\n"
"border:3px solid darkblue;\n"
"}\n"
"\n"
"")
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.label_3 = QtWidgets.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(160, 30, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setUnderline(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("QLabel{\n"
"background:rgb(197, 210, 255);\n"
"color:black;\n"
"}")
        self.label_3.setObjectName("label_3")
        self.txtUser = QtWidgets.QLineEdit(self.groupBox)
        self.txtUser.setGeometry(QtCore.QRect(190, 190, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.txtUser.setFont(font)
        self.txtUser.setStyleSheet("QLineEdit{\n"
            "border-radius:10px;\n"
            "background:white\n"
            "\n"
            "\n"
            "}\n"
            "")
        self.txtUser.setObjectName("txtUser")
        self.txtEmail = QtWidgets.QLineEdit(self.groupBox)
        self.txtEmail.setGeometry(QtCore.QRect(190, 250, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.txtEmail.setFont(font)
        self.txtEmail.setStyleSheet("QLineEdit{\n"
            "border-radius:10px;\n"
            "background:white\n"
            "\n"
            "\n"
            "}\n"
            "")
        self.txtEmail.setObjectName("txtEmail")
        self.txtPass = QtWidgets.QLineEdit(self.groupBox)
        self.txtPass.setGeometry(QtCore.QRect(190, 310, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.txtPass.setFont(font)
        self.txtPass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtPass.setStyleSheet("QLineEdit{\n"
            "border-radius:10px;\n"
            "background:white\n"
            "\n"
            "\n"
            "}\n"
            "")
        self.txtPass.setObjectName("txtPass")
        self.lblUse = QtWidgets.QLabel(self.groupBox)
        self.lblUse.setGeometry(QtCore.QRect(60, 200, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setUnderline(False)
        self.lblUse.setFont(font)
        self.lblUse.setStyleSheet("QLabel{\n"
"background:rgb(197, 210, 255);\n"
"color:black;\n"
"}")
        self.lblUse.setObjectName("lblUse")
        self.lblEmail = QtWidgets.QLabel(self.groupBox)
        self.lblEmail.setGeometry(QtCore.QRect(60, 260, 111, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setUnderline(False)
        self.lblEmail.setFont(font)
        self.lblEmail.setStyleSheet("QLabel{\n"
"background:rgb(197, 210, 255);\n"
"color:black;\n"
"}")
        self.lblEmail.setObjectName("lblEmail")
        self.lblPass = QtWidgets.QLabel(self.groupBox)
        self.lblPass.setGeometry(QtCore.QRect(60, 320, 111, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setUnderline(False)
        self.lblPass.setFont(font)
        self.lblPass.setStyleSheet("QLabel{\n"
"background:rgb(197, 210, 255);\n"
"color:black;\n"
"}")
        self.lblPass.setObjectName("lblPass")
        self.lblcomp = QtWidgets.QLabel(self.groupBox)
        self.lblcomp.setGeometry(QtCore.QRect(150, 360, 171, 41))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(False)
        self.lblcomp.setFont(font)
        self.lblcomp.setStyleSheet("QLabel{\n"
"background:rgb(197, 210, 255);\n"
"color:darkblue;\n"
"\n"
"}")
        self.lblnotcomp = QtWidgets.QLabel(self.groupBox)
        self.lblnotcomp.setGeometry(QtCore.QRect(150, 360, 171, 41))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(False)
        self.lblnotcomp.setFont(font)
        self.lblnotcomp.setStyleSheet("QLabel{\n"
                                   "background:rgb(197, 210, 255);\n"
                                   "color:red;\n"
                                   "\n"
                                   "}")
        self.lblnull = QtWidgets.QLabel(self.groupBox)
        self.lblnull.setGeometry(QtCore.QRect(150, 360, 171, 41))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(False)
        self.lblnull.setFont(font)
        self.lblnull.setStyleSheet("QLabel{\n"
                                      "background:rgb(197, 210, 255);\n"
                                      "color:red;\n"
                                      "\n"
                                      "}")
        self.lbladmin = QtWidgets.QLabel(self.groupBox)
        self.lbladmin.setGeometry(QtCore.QRect(170, 360, 250, 41))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(False)
        self.lbladmin.setFont(font)
        self.lbladmin.setStyleSheet("QLabel{\n"
                                   "background:rgb(197, 210, 255);\n"
                                   "color:red;\n"
                                   "\n"
                                   "}")

        self.groupBox_2 = QtWidgets.QGroupBox(self.groupBox)
        self.groupBox_2.setGeometry(QtCore.QRect(70, 420, 331, 61))
        self.groupBox_2.setStyleSheet("QGroupBox{\n"
"border-radius:20px;\n"
"background:rgb(170, 170, 255)\n"
"}")

        self.groupBox_2.setTitle("")
        self.groupBox_2.setObjectName("groupBox_2")
        self.btnDel = QtWidgets.QPushButton(self.groupBox_2)
        self.btnDel.setGeometry(QtCore.QRect(30, 20, 131, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnDel.setFont(font)
        self.btnDel.setStyleSheet("QPushButton{\n"
            "background-color: rgb(36, 96, 167);\n"
            "color: rgb(255, 255, 255);\n"
            "border-radius:10px;\n"
            "}\n"
            "QPushButton:hover\n"
            "{\n"
            "background:#0094ff;\n"
            "text-transform:uppercase;\n"
            "}")
        self.btnDel.setObjectName("btnDel")
        self.btnExit = QtWidgets.QPushButton(self.groupBox_2)
        self.btnExit.setGeometry(QtCore.QRect(180, 20, 131, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnExit.setFont(font)
        self.btnExit.setStyleSheet("QPushButton{\n"
            "background-color: rgb(36, 96, 167);\n"
            "color: rgb(255, 255, 255);\n"
            "border-radius:10px;\n"
            "}\n"
            "QPushButton:hover\n"
            "{\n"
            "background:#0094ff;\n"
            "text-transform:uppercase;\n"
            "}")
        self.btnExit.setObjectName("btnExit")
        self.label_2 = QtWidgets.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(140, 80, 171, 101))
        self.label_2.setStyleSheet("background:rgb(197, 210, 255);\n"
            "image: url(Images/user_delete.jpeg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.btnExit.clicked.connect(lambda: self.deleteadmin.destroy())
        self.btnDel.clicked.connect(lambda: UiDeleteAdmin.delte(self))
        self.lblcomp.hide()
        self.lblnotcomp.hide()
        self.lblnull.hide()
        self.lbladmin.hide()

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_3.setText(_translate("Dialog", "Delete Account"))
        self.txtUser.setPlaceholderText(_translate("Dialog", "Enter Username"))
        self.txtEmail.setPlaceholderText(_translate("Dialog", "Enter Email"))
        self.txtPass.setPlaceholderText(_translate("Dialog", "Enter Password"))
        self.lblUse.setText(_translate("Dialog", "Username:"))
        self.lblEmail.setText(_translate("Dialog", "Email:"))
        self.lblPass.setText(_translate("Dialog", "Password:"))
        self.lblnull.setText(_translate("Dialog","Fill complete form"))
        self.lblnotcomp.setText(_translate("Dialog","Invalid values"))
        self.lbladmin.setText(_translate("Dialog","Access Denied"))
        self.lblcomp.setText(_translate("Dialog", "Account deleted"))
        self.btnDel.setText(_translate("Dialog", "Delete"))
        self.btnExit.setText(_translate("Dialog", "Exit"))

    def delte(self):
        """This is the method called to delete admin
        from admin table"""
        email, password, username = self.txtEmail.text(), self.txtPass.text(), self.txtUser.text()
        if Validation.mail(email) == 1 and Validation.user_name(username) == 1 and len(password) >= 4:
            obj_admin = Admin()
            get_del = obj_admin.del_admin(username, password, email)
            try:
                if get_del == 1:
                    #  Display Complete Label
                    self.lblcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblcomp.hide()
                    self.deleteadmin.destroy()
                if get_del == 0:
                    self.lblnotcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblnotcomp.hide()
                else:
                    if get_del == 2:
                        #Cannot delete Admin one admin must be present
                        self.lbladmin.show()
                        self.txtPass.clear()
                        self.txtEmail.clear()
                        self.txtUser.clear()
                        loop = QEventLoop()
                        QTimer.singleShot(1000, loop.quit)
                        loop.exec_()
                        self.lbladmin.hide()
            except Exception as error:
                print(error)
        else:
            #when data is invalid
            if email == '' or password == '' or username == '':
                # whwn any field is remained empty
                self.lblnull.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnull.hide()
            else:
                # invalid fileds
                self.lblnotcomp.show()
                if Validation.user_name(username) == 0:
                    self.txtUser.clear()
                if Validation.mail(email) == 0:
                    self.txtEmail.clear()
                if len(password) < 4:
                    self.txtPass.clear()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnotcomp.hide()


class UiViewAcitvity(object):

    def __init__(self):
        self.activity = QtWidgets.QDialog()
        UiViewAcitvity.setupUi(self, self.activity)
        self.activity.show()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label.setStyleSheet("background-image: url(Images/bg.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.groupBox = QtWidgets.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(100, 30, 771, 501))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet("QGroupBox{\n"
                                    "background-color:rgb(197, 210, 255);\n"
                                    "border:3px solid darkblue;\n"
                                    "}\n"
                                    "")
        self.groupBox.setAlignment(QtCore.Qt.AlignLeading | QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        self.groupBox.setObjectName("groupBox")
        self.tableWidget = QtWidgets.QTableWidget(self.groupBox)
        self.tableWidget.setGeometry(QtCore.QRect(140, 100, 531, 341))
        self.tableWidget.setStyleSheet("")
        self.tableWidget.setAlternatingRowColors(True)
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        item.setFont(font)
        item.setBackground(QtGui.QColor(22, 13, 117))
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        self.lblComplete = QtWidgets.QLabel(self.groupBox)
        self.lblComplete.setGeometry(QtCore.QRect(300, 450, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblComplete.setFont(font)
        self.lblComplete.setStyleSheet("QLabel{\n"
                                       "color: rgb(0, 0, 127);\n"
                                       "}")
        self.lblComplete.setObjectName("lblComplete")
        self.lblnotComplete = QtWidgets.QLabel(self.groupBox)
        self.lblnotComplete.setGeometry(QtCore.QRect(300, 450, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblnotComplete.setFont(font)
        self.lblnotComplete.setStyleSheet("QLabel{\n"
                                          "color: red;\n"
                                          "}")
        self.lblnotComplete.setObjectName("lblnotComplete")

        self.lblnot = QtWidgets.QLabel(self.groupBox)
        self.lblnot.setGeometry(QtCore.QRect(300, 450, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblnot.setFont(font)
        self.lblnot.setStyleSheet("QLabel{\n"
                                  "color: red;\n"
                                  "}")
        self.lblnot.setObjectName("lblnotComplete")
        self.btnExit = QtWidgets.QPushButton(self.groupBox)
        self.btnExit.setGeometry(QtCore.QRect(660, 450, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnExit.setFont(font)

        self.btnExit.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}")
        self.btnExit.setObjectName("btnExit")
        self.groupBox_2 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(160, 60, 671, 61))
        self.groupBox_2.setStyleSheet("QGroupBox{\n"
                                      "border-radius:20px;\n"
                                      "background:rgb(170, 170, 255);\n"
                                      "border:2px solid darkblue;\n"
                                      "}")
        self.groupBox_2.setTitle("")
        self.groupBox_2.setObjectName("groupBox_2")
        self.btnsearchname = QtWidgets.QPushButton(self.groupBox_2)
        self.btnsearchname.setGeometry(QtCore.QRect(520, 20, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnsearchname.setFont(font)
        self.btnsearchname.setStyleSheet("QPushButton{\n"
                                         "background-color: rgb(36, 96, 167);\n"
                                         "color: rgb(255, 255, 255);\n"
                                         "border-radius:10px;\n"
                                         "}\n"
                                         "QPushButton:hover\n"
                                         "{\n"
                                         "background:#0094ff;\n"
                                         "text-transform:uppercase;\n"
                                         "}")
        self.btnsearchname.setObjectName("btnsearchname")
        self.btnsearchall = QtWidgets.QPushButton(self.groupBox_2)
        self.btnsearchall.setGeometry(QtCore.QRect(400, 20, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnsearchall.setFont(font)
        self.btnsearchall.setStyleSheet("QPushButton{\n"
                                        "background-color: rgb(36, 96, 167);\n"
                                        "color: rgb(255, 255, 255);\n"
                                        "border-radius:10px;\n"
                                        "}\n"
                                        "QPushButton:hover\n"
                                        "{\n"
                                        "background:#0094ff;\n"
                                        "text-transform:uppercase;\n"
                                        "}")
        self.btnsearchall.setObjectName("btnsearchall")
        self.lbkname = QtWidgets.QLabel(self.groupBox_2)
        self.lbkname.setGeometry(QtCore.QRect(60, 30, 101, 16))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lbkname.setFont(font)
        self.lbkname.setObjectName("lbkname")
        self.txtname = QtWidgets.QLineEdit(self.groupBox_2)
        self.txtname.setGeometry(QtCore.QRect(140, 20, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtname.setFont(font)
        self.txtname.setStyleSheet("QLineEdit{\n"
                                   "border-radius:10px;\n"
                                   "}")
        self.txtname.setObjectName("txtname")
        self.btnsearchall.clicked.connect(lambda: self.search_all())
        self.btnExit.clicked.connect(lambda: self.activity.destroy())
        self.btnsearchname.clicked.connect(lambda: self.search_username(self.txtname.text()))
        self.lblComplete.hide()
        self.lblnot.hide()
        self.lblnotComplete.hide()

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.groupBox.setTitle(_translate("Dialog", "View Activity"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("Dialog", "Session ID"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("Dialog", "     Username    "))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("Dialog", "Time In"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("Dialog", "Time Out"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("Dialog", "Date"))
        self.lblComplete.setText(_translate("Dialog", "Complete!"))
        self.lblnotComplete.setText(_translate("Dialog", "Not Found"))
        self.lblnot.setText(_translate("Dialog", "Inavlid Search"))
        self.btnExit.setText(_translate("Dialog", "Exit"))
        self.btnsearchname.setText(_translate("Dialog", "Username"))
        self.btnsearchall.setText(_translate("Dialog", "Show All"))
        self.lbkname.setText(_translate("Dialog", "Name:"))
        self.txtname.setPlaceholderText(_translate("Dialog", "Enter Name"))

    def search_all(self):

        a = Admin()
        result = a.log_search_all()
        self.tableWidget.setRowCount(0)
        for row, form in enumerate(result):
            self.tableWidget.insertRow(row)
            for column, item in enumerate(form):
                self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
        self.lblComplete.show()
        loop = QEventLoop()
        QTimer.singleShot(1000, loop.quit)
        loop.exec_()
        self.lblComplete.hide()

    def search_username(self, username):
        if Validation.name(username.title()) == 1:
            a = Admin()
            result = a.log_search_name(username.lower())
            if result == 0:
                self.tableWidget.setRowCount(0)
                self.lblnotComplete.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnotComplete.hide()
                self.txtname.clear()
            else:
                if type(result) == tuple:
                    self.tableWidget.setRowCount(0)
                    for row, form in enumerate(result):
                        self.tableWidget.insertRow(row)
                        for column, item in enumerate(form):
                            self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
                    self.lblComplete.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblComplete.hide()
                    self.txtname.clear()
                else:
                    self.tableWidget.setRowCount(0)
                    self.lblnotComplete.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblnotComplete.hide()

        else:
            self.tableWidget.setRowCount(0)
            self.lblnot.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblnot.hide()
            self.txtname.clear()


class UiViewSale(object):
    def __init__(self):

        self.viewsale = QtWidgets.QDialog()
        UiViewSale.setupUi(self,   self.viewsale)
        self.viewsale.show()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        Dialog.setMaximumSize(1008, 583)
        Dialog.setMinimumSize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label.setStyleSheet("image: url(Images/bg.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.groupBox = QtWidgets.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(70, 40, 871, 501))
        self.groupBox.setMinimumSize(QtCore.QSize(871, 501))
        self.groupBox.setMaximumSize(QtCore.QSize(871, 501))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet("QGroupBox{\n"
"background-color:rgb(197, 210, 255);\n"
"border:3px solid darkblue;\n"
"}\n"
"")
        self.groupBox.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.groupBox.setObjectName("groupBox")
        self.tableWidget = QtWidgets.QTableWidget(self.groupBox)
        self.tableWidget.setGeometry(QtCore.QRect(80, 140, 701, 311))
        self.tableWidget.setStyleSheet("")
        self.tableWidget.setAlternatingRowColors(True)
        self.tableWidget.setColumnCount(7)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        item.setFont(font)
        item.setBackground(QtGui.QColor(22, 13, 117))
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        item.setBackground(QtGui.QColor(0, 0, 2))
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, item)
        self.groupBox_2 = QtWidgets.QGroupBox(self.groupBox)
        self.groupBox_2.setGeometry(QtCore.QRect(90, 20, 701, 111))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.groupBox_2.setFont(font)
        self.groupBox_2.setStyleSheet("QGroupBox{\n"
"border-radius:20px;\n"
"background:rgb(170, 170, 255);\n"
"border:2px solid darkblue;\n"
"}")
        self.groupBox_2.setObjectName("groupBox_2")
        self.lblid = QtWidgets.QLabel(self.groupBox_2)
        self.lblid.setGeometry(QtCore.QRect(160, 20, 141, 21))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lblid.setFont(font)
        self.lblid.setObjectName("lblid")
        self.txtid = QtWidgets.QLineEdit(self.groupBox_2)
        self.txtid.setGeometry(QtCore.QRect(320, 20, 241, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtid.setFont(font)
        self.txtid.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtid.setObjectName("txtid")
        self.groupBox_3 = QtWidgets.QGroupBox(self.groupBox_2)
        self.groupBox_3.setGeometry(QtCore.QRect(60, 50, 581, 51))
        self.groupBox_3.setStyleSheet("QGroupBox{\n"
"border-radius:20px;\n"
"background:rgb(170, 170, 255);\n"
"border:2px solid darkblue;\n"
"font-size:11px;\n"
"}\n"
"")
        self.groupBox_3.setObjectName("groupBox_3")
        self.btnrshow = QtWidgets.QPushButton(self.groupBox_3)
        self.btnrshow.setGeometry(QtCore.QRect(30, 20, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnrshow.setFont(font)
        self.btnrshow.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnrshow.setObjectName("btnrshow")
        self.btnProdName = QtWidgets.QPushButton(self.groupBox_3)
        self.btnProdName.setGeometry(QtCore.QRect(160, 20, 121, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnProdName.setFont(font)
        self.btnProdName.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnProdName.setObjectName("btnProdName")
        self.btnCustomer = QtWidgets.QPushButton(self.groupBox_3)
        self.btnCustomer.setGeometry(QtCore.QRect(450, 20, 91, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnCustomer.setFont(font)
        self.btnCustomer.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnCustomer.setObjectName("btnDate")
        self.btnOrderId = QtWidgets.QPushButton(self.groupBox_3)
        self.btnOrderId.setGeometry(QtCore.QRect(310, 20, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnOrderId.setFont(font)
        self.btnOrderId.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnOrderId.setObjectName("btnOrderId")
        self.lblComplete = QtWidgets.QLabel(self.groupBox)
        self.lblComplete.setGeometry(QtCore.QRect(380, 460, 111, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblComplete.setFont(font)
        self.lblComplete.setStyleSheet("QLabel{\n"
"color: rgb(0, 0, 127);\n"
"}")
        self.lblinvalid = QtWidgets.QLabel(self.groupBox)
        self.lblinvalid.setGeometry(QtCore.QRect(320, 460, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblinvalid.setFont(font)
        self.lblinvalid.setStyleSheet("QLabel{\n"
                                       "color: red;\n"
                                       "}")
        self.lblinvalid.setObjectName("lblinvalid")
        self.lblnotfound= QtWidgets.QLabel(self.groupBox)
        self.lblnotfound.setGeometry(QtCore.QRect(320, 460, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblnotfound.setFont(font)
        self.lblnotfound.setStyleSheet("QLabel{\n"
                                      "color: red;\n"
                                      "}")
        self.lblnotfound.setObjectName("lblinvalid")
        self.btnExit = QtWidgets.QPushButton(self.groupBox)
        self.btnExit.clicked.connect(lambda: self.viewsale.destroy())
        self.btnExit.setGeometry(QtCore.QRect(680, 460, 91, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnExit.setFont(font)
        self.btnExit.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnExit.setObjectName("btnExit")
        self.lblComplete.hide()
        self.lblinvalid.hide()
        self.lblnotfound.hide()
        self.btnrshow.clicked.connect(lambda: UiViewSale.all(self))
        self.btnOrderId.clicked.connect(lambda: UiViewSale.by_orderid(self))
        self.btnProdName.clicked.connect(lambda: UiViewSale.by_product(self))
        self.btnCustomer.clicked.connect(lambda: UiViewSale.by_customer(self))
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "View Sale"))
        self.groupBox.setTitle(_translate("Dialog", "View Sale Items"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("Dialog", "Order ID"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("Dialog", "Product ID "))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("Dialog", " Product Name"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("Dialog", "Amount"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("Dialog", "Sale Price"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("Dialog", "Customer "))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("Dialog", "Sale Date"))
        self.groupBox_2.setTitle(_translate("Dialog", "Search Panel"))
        self.lblid.setText(_translate("Dialog", "Required Data"))
        self.txtid.setPlaceholderText(_translate("Dialog", "Search"))
        self.groupBox_3.setTitle(_translate("Dialog", "Search Panel"))
        self.btnrshow.setText(_translate("Dialog", "Show All"))
        self.btnProdName.setText(_translate("Dialog", "Product Name"))
        self.btnCustomer.setText(_translate("Dialog", "Customer"))
        self.btnOrderId.setText(_translate("Dialog", "Order ID"))
        self.lblComplete.setText(_translate("Dialog", "Complete!"))
        self.lblinvalid.setText(_translate("Dialog", "Invalid Search"))
        self.lblnotfound.setText(_translate("Dialog", "Not Found"))
        self.btnExit.setText(_translate("Dialog", "Exit"))

    def all(self):
        try:
            obj = Sales()
            result = obj.get_all()
            self.tableWidget.setRowCount(0)
            for row, form in enumerate(result):
                self.tableWidget.insertRow(row)
                for column, item in enumerate(form):
                    self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
            self.lblComplete.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()

        except Exception as error:
            print(error)
        else:
            self.lblComplete.hide()
            self.txtid.clear()

    def by_orderid(self):

        orderid = self.txtid.text()
        if Validation.amount(orderid) == 1:
            obj = Sales()
            result = obj.search_orderid(orderid)

            if len(result) == 1:
                try:
                    self.tableWidget.setRowCount(0)
                    for row, form in enumerate(result):
                        self.tableWidget.insertRow(row)
                        for column, item in enumerate(form):
                            self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
                    self.lblComplete.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()

                except Exception as error:
                    eror = error
                else:
                    self.lblComplete.hide()
                    self.txtid.clear()
            else:
                # Not found order id label must be displayed
                self.lblnotfound.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnotfound.hide()
                self.txtid.clear()
                self.tableWidget.setRowCount(0)
        else:
            self.tableWidget.setRowCount(0)
            self.lblinvalid.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblinvalid.hide()

    def by_product(self):
        product = self.txtid.text().title()
        if Validation.name(product.title()) == 1:
            obj = Sales()
            result = obj.search_pname(product)
            if len(result) >= 1:
                try:
                    self.tableWidget.setRowCount(0)
                    for row, form in enumerate(result):
                        self.tableWidget.insertRow(row)
                        for column, item in enumerate(form):
                            self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
                    self.lblComplete.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblComplete.hide()
                    self.txtid.clear()
                except Exception as error:
                    error =error
            else:
                self.lblnotfound.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnotfound.hide()
                self.txtid.clear()
                self.tableWidget.setRowCount(0)
        else:
            self.tableWidget.setRowCount(0)
            self.lblinvalid.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblinvalid.hide()

    def by_customer(self):
        customer = self.txtid.text().title()
        if Validation.name(customer) == 1:
            obj = Sales()
            result = obj.search_customer(customer)
            if len(result) > 1:
                try:

                    self.tableWidget.setRowCount(0)
                    for row, form in enumerate(result):
                        self.tableWidget.insertRow(row)
                        for column, item in enumerate(form):
                            self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
                    self.lblComplete.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblComplete.hide()
                    self.txtid.clear()
                except Exception as error:
                    print(error)
            else:
                # Not found order id label must be displayed
                self.lblnotfound.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnotfound.hide()
                self.txtid.clear()
                self.tableWidget.setRowCount(0)
        else:
            self.tableWidget.setRowCount(0)
            self.lblinvalid.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblinvalid.hide()


class UiSale(object):

    def __init__(self):

        self.salew = QtWidgets.QDialog()
        UiSale.setupUi(self, self.salew)
        self.salew.show()
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        Dialog.setMaximumSize(1008, 583)
        Dialog.setMinimumSize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label.setStyleSheet("image: url(Images/bg.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.gbinsert = QtWidgets.QGroupBox(Dialog)
        self.gbinsert.setGeometry(QtCore.QRect(280, 70, 431, 421))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.gbinsert.setFont(font)
        self.gbinsert.setStyleSheet("QGroupBox{\n"
                                    "background-color:rgb(197, 210, 255);\n"
                                    "border:3px solid darkblue;\n"
                                    "}\n"
                                    "")
        self.gbinsert.setTitle("")
        self.gbinsert.setObjectName("gbinsert")
        self.lbldesc = QtWidgets.QLabel(self.gbinsert)
        self.lbldesc.setGeometry(QtCore.QRect(40, 90, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbldesc.setFont(font)
        self.lbldesc.setStyleSheet("QLabel{\n"
                                   "color:black;\n"
                                   "}")
        self.lbldesc.setObjectName("lbldesc")
        self.lblcost = QtWidgets.QLabel(self.gbinsert)
        self.lblcost.setGeometry(QtCore.QRect(40, 150, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblcost.setFont(font)
        self.lblcost.setStyleSheet("QLabel{\n"
                                   "color:black;\n"
                                   "}")
        self.lblcost.setObjectName("lblcost")
        self.txtID = QtWidgets.QLineEdit(self.gbinsert)
        self.txtID.setGeometry(QtCore.QRect(160, 80, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtID.setFont(font)
        self.txtID.setStyleSheet("QLineEdit{\n"
                                 "border-radius:10px;\n"
                                 "}")
        self.txtID.setObjectName("txtID")
        self.txtcos = QtWidgets.QLineEdit(self.gbinsert)
        self.txtcos.setGeometry(QtCore.QRect(160, 140, 241, 31))
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.txtcos.setFont(font)
        self.txtcos.setStyleSheet("QLineEdit{\n"
                                  "border-radius:10px;\n"
                                  "}")
        self.txtcos.setObjectName("txtcos")
        self.btn = QtWidgets.QPushButton(self.gbinsert)
        self.btn.setGeometry(QtCore.QRect(490, 570, 75, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btn.setFont(font)
        self.btn.setToolTipDuration(2)
        self.btn.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.btn.setStyleSheet("QPushButton{\n"
                               "background-color: rgb(36, 96, 167);\n"
                               "color: rgb(255, 255, 255);\n"
                               "border-radius:10px;\n"
                               "}\n"
                               "QPushButton:hover\n"
                               "{\n"
                               "background:#0094ff;\n"
                               "text-transform:uppercase;\n"
                               "}")
        self.btn.setAutoRepeat(False)
        self.btn.setDefault(False)
        self.btn.setFlat(False)
        self.btn.setObjectName("btn")
        self.label_3 = QtWidgets.QLabel(self.gbinsert)
        self.label_3.setGeometry(QtCore.QRect(150, 40, 151, 21))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("QLabel{\n"
                                   "color:black;\n"
                                   "}")
        self.label_3.setObjectName("label_3")
        self.lblamount = QtWidgets.QLabel(self.gbinsert)
        self.lblamount.setGeometry(QtCore.QRect(40, 210, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblamount.setFont(font)
        self.lblamount.setStyleSheet("QLabel{\n"
                                     "color:black;\n"
                                     "}")
        self.lblamount.setObjectName("lblamount")
        self.txtamount = QtWidgets.QLineEdit(self.gbinsert)
        self.txtamount.setGeometry(QtCore.QRect(160, 200, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtamount.setFont(font)
        self.txtamount.setStyleSheet("QLineEdit{\n"
                                     "border-radius:10px;\n"
                                     "}")
        self.txtamount.setObjectName("txtamount")
        self.groupBox = QtWidgets.QGroupBox(self.gbinsert)
        self.groupBox.setGeometry(QtCore.QRect(20, 330, 400, 61))
        self.groupBox.setStyleSheet("QGroupBox{\n"
                                    "border-radius:20px;\n"
                                    "background:rgb(170, 170, 255);\n"
                                    "border:2px solid darkblue;\n"
                                    "}")
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.btnInsert = QtWidgets.QPushButton(self.groupBox)
        self.btnInsert.clicked.connect(lambda : UiSale.sale(self))
        self.btnInsert.setGeometry(QtCore.QRect(30, 20, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnInsert.setFont(font)
        self.btnInsert.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}")
        self.btnInsert.setObjectName("btnInsert")
        self.btnbill = QtWidgets.QPushButton(self.groupBox)
        #self.btnbill.clicked.connect(lambda: UiSale.sale(self))
        self.btnbill.setGeometry(QtCore.QRect(160, 20, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnbill.setFont(font)
        self.btnbill.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}")
        self.btnbill.setObjectName("btnInsert")
        self.btnbill.clicked.connect(lambda :UiSale.show_bill(self))
        self.btnExit = QtWidgets.QPushButton(self.groupBox)
        self.btnExit.clicked.connect(lambda :self.salew.destroy())
        self.btnExit.setGeometry(QtCore.QRect(280, 20, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnExit.setFont(font)
        self.btnExit.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}")
        self.btnExit.setObjectName("btnExit")
        self.lblcomp = QtWidgets.QLabel(self.gbinsert)
        self.lblcomp.setGeometry(QtCore.QRect(140, 280, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblcomp.setFont(font)
        self.lblcomp.setStyleSheet("QLabel{\n"
                                   "color:darkblue;\n"
                                   "text-align:centre;\n"
                                   "}")
        self.lblcomp.setObjectName("lblcomp")
        self.lblnotcomp = QtWidgets.QLabel(self.gbinsert)
        self.lblnotcomp.setGeometry(QtCore.QRect(140, 280, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblnotcomp.setFont(font)
        self.lblnotcomp.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "text-align:centre;\n"
                                   "}")
        self.lblnotcomp.setObjectName("lblnotcomp")
        self.lblinvalid = QtWidgets.QLabel(self.gbinsert)
        self.lblinvalid.setGeometry(QtCore.QRect(140, 280, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblinvalid.setFont(font)
        self.lblinvalid.setStyleSheet("QLabel{\n"
                                      "color:red;\n"
                                      "text-align:centre;\n"
                                      "}")
        self.lblinvalid.setObjectName("lblnotcomp")
        self.lblout = QtWidgets.QLabel(self.gbinsert)
        self.lblout.setGeometry(QtCore.QRect(120, 280, 200, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblout.setFont(font)
        self.lblout.setStyleSheet("QLabel{\n"
                                      "color:red;\n"
                                      "text-align:centre;\n"
                                      "}")
        self.lblout.setObjectName("lblnotcomp")
        self.lblnot = QtWidgets.QLabel(self.gbinsert)
        self.lblnot.setGeometry(QtCore.QRect(140, 280, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblnot.setFont(font)
        self.lblnot.setStyleSheet("QLabel{\n"
                                  "color:red;\n"
                                  "text-align:centre;\n"
                                  "}")
        self.lblnot.setObjectName("lblnotcomp")
        self.lblinvalid.hide()
        self.lblnotcomp.hide()
        self.lblnot.hide()
        self.lblout.hide()
        self.lblcomp.hide()
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Sales"))
        self.lbldesc.setText(_translate("Dialog", "Product ID:"))
        self.lblcost.setText(_translate("Dialog", "Customer:"))
        self.txtID.setPlaceholderText(_translate("Dialog", "Enter Product ID"))
        self.txtcos.setPlaceholderText(_translate("Dialog", "Enter Customer"))
        self.btn.setToolTip(_translate("Dialog", "Load Latest Data"))
        self.btn.setText(_translate("Dialog", "Refresh"))
        self.label_3.setText(_translate("Dialog", " Sale Items"))
        self.lblamount.setText(_translate("Dialog", "Amount:"))
        self.txtamount.setPlaceholderText(_translate("Dialog", "Enter Amount"))
        self.btnInsert.setToolTip(_translate("Dialog", "sell item"))
        self.btnInsert.setText(_translate("Dialog", "sale"))
        self.btnExit.setText(_translate("Dialog", "Exit"))
        self.btnbill.setText(_translate("Dialog","Show Bill"))
        self.lblcomp.setText(_translate("Dialog", "Generating Bill"))
        self.lblnotcomp.setText(_translate("Dialog", "Fill al fields"))
        self.lblinvalid.setText(_translate("Dialog", "Invalid Details"))
        self.lblout.setText(_translate("Dialog", "Product Out of Stock"))
        self.lblnot.setText(_translate("Dialog", "Product Not Found"))

    def show_bill(self):
        a = Sales()
        try:
            if Validation.name(self.txtcos.text().title()) == 1:
                result = a.bill(self.txtcos.text().title())
                self.obj = UiBill(result[0] ,result[1] ,result[2] , result[3], result[4])
        except Exception as erro:
            print(erro)

    def sale(self):
        try:

            id_p = self.txtID.text()
            amount = self.txtamount.text()
            customer = self.txtcos.text()
            if Validation.amount(id_p) == 1 and Validation.amount(amount) == 1 and Validation.name(customer) and int(amount) >= 1:

                obj = Purchase()
                res = obj.purchase(id_p, amount, customer)
                if res == 1:
                    # This part of code will proceed when everything will be fine
                    self.lblcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblcomp.hide()
                else:
                    # when something goes wrong then this part will execute
                    if res == 2:
                        # when quantity is not available
                        self.lblout.show()
                        loop = QEventLoop()
                        QTimer.singleShot(3000, loop.quit)
                        loop.exec_()
                        self.lblout.hide()
                    else:
                        # when product is not found
                        self.lblnot.show()
                        loop = QEventLoop()
                        QTimer.singleShot(1000, loop.quit)
                        loop.exec_()
                        self.lblnot.hide()
            else:
                if id_p == '' or amount == '' or customer == '':
                    # when any filed is remain empty
                    self.lblnotcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblnotcomp.hide()
                else:
                    # if any input is wrong
                    self.lblinvalid.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblinvalid.hide()
                    if Validation.amount(id_p) == 0:
                        self.txtID.clear()
                    if Validation.amount(amount) == 0:
                        self.txtamount.clear()
                    if Validation.name(customer) == 0:
                        self.txtcos.clear()
        except Exception as error:
            print(error)


class UiChangePassword(object):

    def __init__(self):

        self.changepassword = QtWidgets.QDialog()
        UiChangePassword.setupUi(self, self.changepassword)
        self.changepassword.show()

    def setupUi(self, ForgetPassword):
        """
        -----------Instructions---------
        ->Button objects start with 'btn'
        ->LineEdit objects start with 'txt'
        ->Label objects start with 'lbl'
        """
        ForgetPassword.setObjectName("ForgetPassword")
        ForgetPassword.resize(449, 585)
        ForgetPassword.setStyleSheet("QDialog{\n"
"background-color: rgb(197, 210, 255);\n"
"}")
        self.label_3 = QtWidgets.QLabel(ForgetPassword)
        self.label_3.setGeometry(QtCore.QRect(120, 10, 211, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(18)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("Qlabel{\n"       
"font-color:rgb(255, 255, 255)\n"
"}")
        self.label_3.setObjectName("label_3")
        self.label_2 = QtWidgets.QLabel(ForgetPassword)
        self.label_2.setGeometry(QtCore.QRect(30, 90, 301, 21))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("QLabel{\n"
"color:darkblue;\n"
"}")
        self.label_2.setObjectName("label_2")
        self.lblOld = QtWidgets.QLabel(ForgetPassword)
        self.lblOld.setGeometry(QtCore.QRect(70, 310, 121, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblOld.setFont(font)
        self.lblOld.setObjectName("lblOld")
        self.txtold = QtWidgets.QLineEdit(ForgetPassword)
        self.txtold.setGeometry(QtCore.QRect(230, 300, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtold.setFont(font)
        self.txtold.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtold.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtold.setObjectName("txtold")
        self.btnSubmit = QtWidgets.QPushButton(ForgetPassword)
        self.btnSubmit.setGeometry(QtCore.QRect(60, 520, 331, 51))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.btnSubmit.setFont(font)
        self.btnSubmit.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnSubmit.setObjectName("btnSubmit")
        self.label_4 = QtWidgets.QLabel(ForgetPassword)
        self.label_4.setGeometry(QtCore.QRect(86, 460, 271, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("QLabel{\n"
"color:darkblue;\n"
"}\n"
"")
        self.label_4.setAlignment(QtCore.Qt.AlignBottom|QtCore.Qt.AlignHCenter)
        self.label_4.setObjectName("label_4")
        self.label_4 = QtWidgets.QLabel(ForgetPassword)
        self.label_4.setGeometry(QtCore.QRect(76, 460, 300, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("QLabel{\n"
                                   "color:darkblue;\n"
                                   "}\n"
                                   "")
        self.label_4.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(ForgetPassword)
        self.label_5.setGeometry(QtCore.QRect(86, 460, 321, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_5.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_5.setObjectName("label_45")
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_5.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_5.setObjectName("label_46")
        self.label_6 = QtWidgets.QLabel(ForgetPassword)
        self.label_6.setGeometry(QtCore.QRect(86, 460, 271, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_6.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_6.setObjectName("label_45")
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_6.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_6.setObjectName("label_46")
        self.label_7 = QtWidgets.QLabel(ForgetPassword)
        self.label_7.setGeometry(QtCore.QRect(86, 460, 271, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_7.setFont(font)
        self.label_7.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_7.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_7.setObjectName("label_45")

        self.label_8 = QtWidgets.QLabel(ForgetPassword)
        self.label_8.setGeometry(QtCore.QRect(86, 460, 271, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_8.setFont(font)
        self.label_8.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_8.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_8.setObjectName("label_45")
        self.label_9 = QtWidgets.QLabel(ForgetPassword)
        self.label_9.setGeometry(QtCore.QRect(86, 460, 271, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_9.setFont(font)
        self.label_9.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_9.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_9.setObjectName("label_45")

        self.lblNew = QtWidgets.QLabel(ForgetPassword)
        self.lblNew.setGeometry(QtCore.QRect(70, 360, 121, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblNew.setFont(font)
        self.lblNew.setObjectName("lblNew")
        self.txtnew = QtWidgets.QLineEdit(ForgetPassword)
        self.txtnew.setGeometry(QtCore.QRect(230, 350, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtnew.setFont(font)
        self.txtnew.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtnew.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtnew.setObjectName("txtnew")
        self.txtcon = QtWidgets.QLineEdit(ForgetPassword)
        self.txtcon.setGeometry(QtCore.QRect(230, 400, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtcon.setFont(font)
        self.txtcon.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtcon.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtcon.setObjectName("txtcon")
        self.lblcon = QtWidgets.QLabel(ForgetPassword)
        self.lblcon.setGeometry(QtCore.QRect(70, 410, 141, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblcon.setFont(font)
        self.lblcon.setObjectName("lblcon")
        self.label = QtWidgets.QLabel(ForgetPassword)
        self.label.setGeometry(QtCore.QRect(160, 120, 121, 91))
        self.label.setStyleSheet("image: url(Images/login1.png);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.lbluser = QtWidgets.QLabel(ForgetPassword)
        self.lbluser.setGeometry(QtCore.QRect(70, 260, 121, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbluser.setFont(font)
        self.lbluser.setObjectName("lbluser")
        self.txtuseer = QtWidgets.QLineEdit(ForgetPassword)
        self.txtuseer.setGeometry(QtCore.QRect(230, 250, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtuseer.setFont(font)
        self.txtuseer.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtuseer.setObjectName("txtuseer")
        self.label_4.hide()
        self.label_5.hide()
        self.label_6.hide()
        self.label_7.hide()
        self.label_8.hide()
        self.label_9.hide()
        self.btnSubmit.clicked.connect(lambda: UiChangePassword.update(self))
        self.retranslateUi(ForgetPassword)
        QtCore.QMetaObject.connectSlotsByName(ForgetPassword)

    def retranslateUi(self, ForgetPassword):
        _translate = QtCore.QCoreApplication.translate
        ForgetPassword.setWindowTitle(_translate("ForgetPassword", "Change Password"))
        self.label_3.setText(_translate("ForgetPassword", "Change Password"))
        self.label_2.setText(_translate("ForgetPassword", "Enter password you want to change :"))
        self.lblOld.setText(_translate("ForgetPassword", "Old Password:"))
        self.txtold.setPlaceholderText(_translate("ForgetPassword", "Enter Old Password"))
        self.btnSubmit.setText(_translate("ForgetPassword", "Submit"))
        self.label_4.setText(_translate("ForgetPassword", "Password Updated"))
        self.label_5.setText(_translate("ForgetPassword", "Invalid Username or Password"))
        self.label_7.setText(_translate("ForgetPassword", "Passwords Dont Match"))
        self.label_8.setText(_translate("ForgetPassword", "Passwords Length too short "))
        self.label_9.setText(_translate("ForgetPassword", "Incomplete Fields"))
        self.lblNew.setText(_translate("ForgetPassword", "New Password:"))
        self.txtnew.setPlaceholderText(_translate("ForgetPassword", "Enter New Password"))
        self.txtcon.setPlaceholderText(_translate("ForgetPassword", "Confirm Password"))
        self.lblcon.setText(_translate("ForgetPassword", "Confirm Password:"))
        self.lbluser.setText(_translate("ForgetPassword", "Username:"))
        self.txtuseer.setPlaceholderText(_translate("ForgetPassword", "Enter Username"))

    def update(self):
        username = self.txtuseer.text()
        old_pass = self.txtold.text()
        new_pass = self.txtnew.text()
        con_pass = self.txtcon.text()
        if Validation.user_name(username) == 1 and new_pass == con_pass and old_pass != '' and new_pass != '':
            if len(new_pass) >= 4:
                admin_obj = Admin()
                a = admin_obj.update_pass(username,  old_pass, new_pass)
                if a == 0:
                    self.label_5.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.label_5.hide()

                if a == 1:
                    try:
                        ab = Email(admin_obj.get_email(username), admin_obj.get_name(username), username)
                        ab.pass_change()
                    except Exception as error:
                        print(error)
                    else:
                        self.label_4.show()
                        loop = QEventLoop()
                        QTimer.singleShot(1000, loop.quit)
                        loop.exec_()
                        self.changepassword.destroy()
                        self.label_4.hide()
            else:
                self.label_8.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_8.hide()
            try:
                pass
            except Exception as error:
                print(error)
            else:
                pass

        else:
            if new_pass != con_pass:
                self.label_7.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_7.hide()
            if username == '' or con_pass == '' or new_pass == '' or old_pass == '':
                self.label_9.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_9.hide()


class UiEditItems(object):

    def __init__(self):

        self.edititems = QtWidgets.QDialog()
        UiEditItems .setupUi(self, self.edititems)
        self.edititems.show()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        Dialog.setMaximumSize(1008, 583)
        Dialog.setMinimumSize(1008, 583)
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label_2.setStyleSheet("background-image: url(Images/bg.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.gbinsert = QtWidgets.QGroupBox(Dialog)
        self.gbinsert.setGeometry(QtCore.QRect(275, 30, 431, 491))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.gbinsert.setFont(font)
        self.gbinsert.setStyleSheet("QGroupBox{\n"
"background-color:rgb(197, 210, 255);\n"
"border:3px solid darkblue;\n"
"}\n"
"")
        self.gbinsert.setTitle("")
        self.gbinsert.setObjectName("gbinsert")
        self.lblcost = QtWidgets.QLabel(self.gbinsert)
        self.lblcost.setGeometry(QtCore.QRect(40, 180, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblcost.setFont(font)
        self.lblcost.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblcost.setObjectName("lblcost")
        self.txtID = QtWidgets.QLineEdit(self.gbinsert)
        self.txtID.setGeometry(QtCore.QRect(160, 110, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.txtID.setFont(font)
        self.txtID.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"\n"
"\n"
"}\n"
"")
        self.txtID.setObjectName("txtID")
        self.txtcost = QtWidgets.QLineEdit(self.gbinsert)
        self.txtcost.setGeometry(QtCore.QRect(160, 170, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.txtcost.setFont(font)
        self.txtcost.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtcost.setObjectName("txtcost")
        self.txtsell = QtWidgets.QLineEdit(self.gbinsert)
        self.txtsell.setGeometry(QtCore.QRect(160, 230, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.txtsell.setFont(font)
        self.txtsell.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
";\n"
"}")
        self.txtsell.setObjectName("txtsell")
        self.lblsell = QtWidgets.QLabel(self.gbinsert)
        self.lblsell.setGeometry(QtCore.QRect(40, 240, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblsell.setFont(font)
        self.lblsell.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblsell.setObjectName("lblsell")
        self.lblid = QtWidgets.QLabel(self.gbinsert)
        self.lblid.setGeometry(QtCore.QRect(40, 120, 71, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblid.setFont(font)
        self.lblid.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblid.setObjectName("lblid")
        self.btnRefresh = QtWidgets.QPushButton(self.gbinsert)
        self.btnRefresh.setGeometry(QtCore.QRect(490, 570, 75, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnRefresh.setFont(font)
        self.btnRefresh.setToolTipDuration(2)
        self.btnRefresh.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.btnRefresh.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnRefresh.setAutoRepeat(False)
        self.btnRefresh.setDefault(False)
        self.btnRefresh.setFlat(False)
        self.btnRefresh.setObjectName("btnRefresh")
        self.label_3 = QtWidgets.QLabel(self.gbinsert)
        self.label_3.setGeometry(QtCore.QRect(90, 30, 251, 21))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.label_3.setObjectName("label_3")
        self.groupBox = QtWidgets.QGroupBox(self.gbinsert)
        self.groupBox.setGeometry(QtCore.QRect(50, 380, 331, 61))
        self.groupBox.setStyleSheet("QGroupBox{\n"
"border-radius:20px;\n"
"background:rgb(170, 170, 255)\n"
"}")
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.btnupdate = QtWidgets.QPushButton(self.groupBox)
        self.btnupdate.setGeometry(QtCore.QRect(30, 20, 131, 31))
        self.btnupdate.clicked.connect(lambda: UiEditItems.update_items(self))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnupdate.setFont(font)
        self.btnupdate.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnupdate.setObjectName("btnupdate")
        self.btnExit = QtWidgets.QPushButton(self.groupBox)
        self.btnExit.setGeometry(QtCore.QRect(180, 20, 131, 31))
        self.btnExit.clicked.connect(lambda: self.edititems.destroy())
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnExit.setFont(font)
        self.btnExit.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnExit.setObjectName("btnExit")
        self.lblcomp = QtWidgets.QLabel(self.gbinsert)
        self.lblcomp.setGeometry(QtCore.QRect(170, 300, 111, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblcomp.setFont(font)
        self.lblcomp.setStyleSheet("QLabel{\n"
"color:darkblue;\n"
"}")
        self.lblcomp.setObjectName("lblcomp")
        self.lblcomp.hide()
        self.lblnotcomp = QtWidgets.QLabel(self.gbinsert)
        self.lblnotcomp.setGeometry(QtCore.QRect(150, 300, 171, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblnotcomp.setFont(font)
        self.lblnotcomp.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}")
        self.lblnotcomp.setObjectName("lblcomp")
        self.lblnotcomp.hide()
        self.lblnotval = QtWidgets.QLabel(self.gbinsert)
        self.lblnotval.setGeometry(QtCore.QRect(150, 300, 171, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblnotval.setFont(font)
        self.lblnotval.setStyleSheet("QLabel{\n"
                                      "color:red;\n"
                                      "}")
        self.lblnotval.setObjectName("lblcomp")
        self.lblnotval.hide()
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Update Item"))
        self.lblcost.setText(_translate("Dialog", "Cost Price:"))
        self.txtID.setPlaceholderText(_translate("Dialog", "Enter ID"))
        self.txtcost.setPlaceholderText(_translate("Dialog", "Enter Cost Price"))
        self.txtsell.setPlaceholderText(_translate("Dialog", "Enter Sell Price"))
        self.lblsell.setText(_translate("Dialog", "Selling Price:"))
        self.lblid.setText(_translate("Dialog", "ID:"))
        self.btnRefresh.setToolTip(_translate("Dialog", "Load Latest Data"))
        self.btnRefresh.setText(_translate("Dialog", "Refresh"))
        self.label_3.setText(_translate("Dialog", "Update and Delete Items"))
        self.btnupdate.setText(_translate("Dialog", "Update"))
        self.btnExit.setText(_translate("Dialog", "Exit"))
        self.lblcomp.setText(_translate("Dialog", "Complete!"))
        self.lblnotval.setText(_translate("Dialog", "Invalid Details"))
        self.lblnotcomp.setText(_translate("Dialog", "Please fill all fields"))

    def update_items(self):
        id_u = self.txtID.text()
        cost_u = self.txtcost.text()
        sell_u = self.txtsell.text()

        if Validation.amount(id_u) == 1 and Validation.amount(cost_u) == 1 and Validation.amount(sell_u) == 1:
            if cost_u > sell_u:
                self.lblnotval.show()
                loop = QEventLoop()
                QTimer.singleShot(3000, loop.quit)
                loop.exec_()
                self.lblnotval.hide()
                self.txtsell.clear()
                self.txtcost.clear()
            else:
                obj_pruchase = Purchase()
                result = obj_pruchase.set_purchase(id_u, cost_u, sell_u)
                if result == 1:
                    self.lblcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(3000, loop.quit)
                    loop.exec_()
                    self.lblcomp.hide()
                else:
                    self.lblnotcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(3000, loop.quit)
                    loop.exec_()
                    self.lblnotcomp.hide()
        else:
            if id_u == '' or cost_u == '' or sell_u == '':
                # if any entry will remain empty then this part will execute
                self.lblnotcomp.show()
                loop = QEventLoop()
                QTimer.singleShot(3000, loop.quit)
                loop.exec_()
                self.lblnotcomp.hide()
            else:
                self.lblnotval.show()
                loop = QEventLoop()
                QTimer.singleShot(3000, loop.quit)
                loop.exec_()
                self.lblnotval.hide()
                if Validation.amount(id_u) == 0:
                    self.txtID.clear()
                if Validation.amount(cost_u) == 0:
                    self.txtcost.clear()
                if Validation.amount(sell_u) == 0:
                    self.txtsell.clear()


class UiSignUp(object):

    def __init__(self):
        self.signup = QtWidgets.QDialog()
        UiSignUp.setupUi(self, self.signup)
        self.signup.show()

    def setupUi(self, SignUp):  # Signup body
        SignUp.setObjectName("SignUp")
        SignUp.resize(449, 555)
        SignUp.setStyleSheet("QDialog{\n"
                             "background-color: rgb(197, 210, 255);\n"
                             "}")
        self.txtuser = QtWidgets.QLineEdit(SignUp)
        self.txtuser.setGeometry(QtCore.QRect(220, 180, 221, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtuser.setFont(font)
        self.txtuser.setStyleSheet("QLineEdit{\n"
                                   "border-radius:10px;\n"
                                   "}")
        self.txtuser.setObjectName("txtuser")
        self.lblUser = QtWidgets.QLabel(SignUp)
        self.lblUser.setGeometry(QtCore.QRect(80, 190, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblUser.setFont(font)
        self.lblUser.setObjectName("lblUser")
        self.lblsignup = QtWidgets.QLabel(SignUp)
        self.lblsignup.setGeometry(QtCore.QRect(140, 0, 171, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(18)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.lblsignup.setFont(font)
        self.lblsignup.setStyleSheet("Qlabel{\n"
                                     "font-color:rgb(255, 255, 255)\n"
                                     "}")
        self.lblsignup.setObjectName("lblsignup")
        self.lblEmail = QtWidgets.QLabel(SignUp)
        self.lblEmail.setGeometry(QtCore.QRect(80, 260, 71, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblEmail.setFont(font)
        self.lblEmail.setObjectName("lblEmail")
        self.txtmail = QtWidgets.QLineEdit(SignUp)
        self.txtmail.setGeometry(QtCore.QRect(220, 250, 221, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtmail.setFont(font)
        self.txtmail.setStyleSheet("QLineEdit{\n"
                                   "border-radius:10px;\n"
                                   "}")
        self.txtmail.setObjectName("txtmail")
        self.txtpass = QtWidgets.QLineEdit(SignUp)
        self.txtpass.setGeometry(QtCore.QRect(220, 310, 221, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtpass.setFont(font)
        self.txtpass.setStyleSheet("QLineEdit{\n"
                                   "border-radius:10px;\n"
                                   "}")
        self.txtpass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtpass.setObjectName("txtpass")
        self.txtconpass = QtWidgets.QLineEdit(SignUp)
        self.txtconpass.setGeometry(QtCore.QRect(220, 370, 221, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtconpass.setFont(font)
        self.txtconpass.setStyleSheet("QLineEdit{\n"
                                      "border-radius:10px;\n"
                                      "}")
        self.txtconpass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtconpass.setObjectName("txtconpass")
        self.lblPass = QtWidgets.QLabel(SignUp)
        self.lblPass.setGeometry(QtCore.QRect(80, 320, 73, 19))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblPass.setFont(font)
        self.lblPass.setObjectName("lblPass")
        self.lblConfirmPass = QtWidgets.QLabel(SignUp)
        self.lblConfirmPass.setGeometry(QtCore.QRect(80, 380, 141, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblConfirmPass.setFont(font)
        self.lblConfirmPass.setObjectName("lblConfirmPass")
        self.btnsign = QtWidgets.QPushButton(SignUp)  # for signup button
        self.btnsign.setGeometry(QtCore.QRect(70, 480, 331, 51))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.btnsign.setFont(font)
        self.btnsign.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}")
        self.btnsign.setObjectName("btnsign")
        self.txtFirst = QtWidgets.QLineEdit(SignUp)
        self.txtFirst.setGeometry(QtCore.QRect(220, 60, 221, 31))
        self.btnsign.clicked.connect(self.on_click)  # button function calling (signup button)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtFirst.setFont(font)
        self.txtFirst.setStyleSheet("QLineEdit{\n"
                                    "border-radius:10px;\n"
                                    "}\n"
                                    "")
        self.txtFirst.setObjectName("txtFirst")
        self.lblFirst = QtWidgets.QLabel(SignUp)
        self.lblFirst.setGeometry(QtCore.QRect(80, 70, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblFirst.setFont(font)
        self.lblFirst.setObjectName("lblFirst")
        self.lblLast = QtWidgets.QLabel(SignUp)
        self.lblLast.setGeometry(QtCore.QRect(80, 130, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblLast.setFont(font)
        self.lblLast.setObjectName("lblLast")
        self.txtLast = QtWidgets.QLineEdit(SignUp)
        self.txtLast.setGeometry(QtCore.QRect(220, 120, 221, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtLast.setFont(font)
        self.txtLast.setStyleSheet("QLineEdit{\n"
                                   "border-radius:10px;\n"
                                   "}")
        self.txtLast.setObjectName("txtLast")
        self.lblimgfirst = QtWidgets.QLabel(SignUp)
        self.lblimgfirst.setGeometry(QtCore.QRect(10, 50, 51, 51))
        self.lblimgfirst.setStyleSheet("image : url(Images/default.png);")
        self.lblimgfirst.setText("")
        self.lblimgfirst.setObjectName("lblimgfirst")
        self.lblimglast = QtWidgets.QLabel(SignUp)
        self.lblimglast.setGeometry(QtCore.QRect(10, 120, 51, 51))
        self.lblimglast.setStyleSheet("image : url(Images/default.png);")
        self.lblimglast.setText("")
        self.lblimglast.setObjectName("lblimglast")
        self.lblimguser = QtWidgets.QLabel(SignUp)
        self.lblimguser.setGeometry(QtCore.QRect(10, 180, 51, 51))
        self.lblimguser.setStyleSheet("image: url(Images/default.png);")
        self.lblimguser.setText("")
        self.lblimguser.setObjectName("lblimguser")
        self.lblimgmail = QtWidgets.QLabel(SignUp)
        self.lblimgmail.setGeometry(QtCore.QRect(10, 250, 51, 51))
        self.lblimgmail.setStyleSheet("image: url(Images/Mail-512.png);")
        self.lblimgmail.setText("")
        self.lblimgmail.setObjectName("lblimgmail")
        self.lblimgconf = QtWidgets.QLabel(SignUp)
        self.lblimgconf.setGeometry(QtCore.QRect(10, 370, 51, 51))
        self.lblimgconf.setStyleSheet("image: url(Images/password.png);")
        self.lblimgconf.setText("")
        self.lblimgconf.setObjectName("lblimgconf")
        self.lblimgpass = QtWidgets.QLabel(SignUp)
        self.lblimgpass.setGeometry(QtCore.QRect(10, 310, 51, 51))
        self.lblimgpass.setStyleSheet("image: url(Images/password.png);")
        self.lblimgpass.setText("")
        self.lblimgpass.setObjectName("lblimgpass")
        self.lblreg = QtWidgets.QLabel(SignUp)
        self.lblreg.setGeometry(QtCore.QRect(130, 430, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lblreg.setFont(font)
        self.lblreg.setStyleSheet("QLabel{\n"
                                  "color: rgb(0, 0, 127);\n"
                                  "}")
        self.lblreg.setObjectName("lblreg")  # Registration Completed
        self.lblreg.hide()  # Hide Registration Completed label
        self.lblnotreg = QtWidgets.QLabel(SignUp)
        self.lblnotreg.setGeometry(QtCore.QRect(130, 430, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lblnotreg.setFont(font)
        self.lblnotreg.setStyleSheet("QLabel{\n"
                                  "color: red;\n"
                                  "}")
        self.lblnotreg.setObjectName("lblnotreg")  # Registration Completed
        self.lblnotreg.hide()  # Hide Registration Completed label
        self.lblnotpass = QtWidgets.QLabel(SignUp)
        self.lblnotpass.setGeometry(QtCore.QRect(130, 430, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lblnotpass.setFont(font)
        self.lblnotpass.setStyleSheet("QLabel{\n"
                                     "color: red;\n"
                                     "}")
        self.lblnotpass.setObjectName("lblnotpass")  # Registration Completed
        self.lblnotpass.hide()  # Hide Registration Completed label
        self.lblshortpass = QtWidgets.QLabel(SignUp)
        self.lblshortpass.setGeometry(QtCore.QRect(130, 430, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lblshortpass.setFont(font)
        self.lblshortpass.setStyleSheet("QLabel{\n"
                                      "color: red;\n"
                                      "}")
        self.lblshortpass.setObjectName("lblshortpass")  # Registration Completed
        self.lblshortpass.hide()  # Hide Registration Completed label
        self.lblnotcomp = QtWidgets.QLabel(SignUp)
        self.lblnotcomp.setGeometry(QtCore.QRect(130, 430, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lblnotcomp.setFont(font)
        self.lblnotcomp.setStyleSheet("QLabel{\n"
                                        "color: red;\n"
                                        "}")
        self.lblnotcomp.setObjectName("lblnotcomp")  # Registration Completed
        self.lblnotcomp.hide()  # Hide Registration Completed label
        self.lblstshort = QtWidgets.QLabel(SignUp)
        self.lblstshort.setGeometry(QtCore.QRect(220, 340, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblstshort.setFont(font)
        self.lblstshort.setStyleSheet("QLabel{\n"
                                        "color: red;\n"
                                        "}")
        self.lblstsmed = QtWidgets.QLabel(SignUp)
        self.lblstsmed.setGeometry(QtCore.QRect(220, 340, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblstsmed.setFont(font)
        self.lblstsmed.setStyleSheet("QLabel{\n"
                                      "color:green;\n"
                                      "}")
        self.lblstlong = QtWidgets.QLabel(SignUp)
        self.lblstlong.setGeometry(QtCore.QRect(220, 340, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblstlong.setFont(font)
        self.lblstlong.setStyleSheet("QLabel{\n"
                                     "color:Blue;\n"
                                     "}")
        self.lblstlong.hide()
        self.lblstshort.hide()
        self.lblstsmed.hide()
        self.retranslateUi(SignUp)
        QtCore.QMetaObject.connectSlotsByName(SignUp)

    def retranslateUi(self, SignUp):
        _translate = QtCore.QCoreApplication.translate
        SignUp.setWindowTitle(_translate("SignUp", "SignUp"))
        self.lblUser.setText(_translate("SignUp", "Username:"))
        self.lblsignup.setText(_translate("SignUp", "Sign Up Form"))
        self.lblEmail.setText(_translate("SignUp", "E-mail:"))
        self.lblPass.setText(_translate("SignUp", "Password:"))
        self.lblConfirmPass.setText(_translate("SignUp", "Confirm Password:"))
        self.btnsign.setText(_translate("SignUp", "Sign Me Up"))
        self.lblFirst.setText(_translate("SignUp", "First Name:"))
        self.lblLast.setText(_translate("SignUp", "Last Name:"))
        self.lblreg.setText(_translate("SignUp", "Registration Complete!"))
        self.lblnotreg.setText(_translate("SignUp", "Invalid Details Please check again"))
        self.lblnotpass.setText(_translate("SignUp", "Passwords Do not Match"))
        self.lblshortpass.setText(_translate("Log In","Password length too short"))
        self.lblnotcomp.setText(_translate("Log In", "Fields Incomplete"))
        self.lblstsmed.setText(_translate("Log In", "Password Strength: Medium"))
        self.lblstshort.setText(_translate("Log In", "Password Strength: Weak"))
        self.lblstlong.setText(_translate("Log In", "Password Strength: Strong"))
        self.txtFirst.setPlaceholderText('First Name')
        self.txtLast.setPlaceholderText('Last Name')
        self.txtconpass.setPlaceholderText('Confirm Password')
        self.txtmail.setPlaceholderText('Email')
        self.txtpass.setPlaceholderText('Create Password')
        self.txtuser.setPlaceholderText('Enter a username')



    def on_click(self):
        """This will show that the person is successfully
        registered after signup button is clicked"""
        try:
            f_name = self.txtFirst.text()
            l_name = self.txtLast.text()
            u_name = self.txtuser.text()
            mail = self.txtmail.text()
            password = self.txtpass.text()
            con_pass = self.txtconpass.text()
            v_mail = Validation.mail(mail)
            v_f_name = Validation.name(f_name)
            v_l_name = Validation.name(l_name)
            v_username = Validation.user_name(u_name)
            if len(str(password)) <= 4:
                self.lblstshort.show()
            else:
                self.lblstshort.hide()
            if 4 < len(password) <= 6:
                self.lblstsmed.show()
            else:
                self.lblstsmed.hide()
            if len(password) > 6:
                self.lblstlong.show()
            else:
                self.lblstlong.hide()
            if Validation.user_name(u_name) == 1 and v_mail == 1 and v_f_name == 1 and v_l_name == 1:
                if password == con_pass:

                    if len(password) < 4:
                        self.lblshortpass.show()
                        loop = QEventLoop()
                        QTimer.singleShot(1000, loop.quit)
                        loop.exec_()
                        self.lblshortpass.hide()
                    else:
                        try:
                            self.lblreg.show()
                            loop = QEventLoop()
                            QTimer.singleShot(1000, loop.quit)
                            loop.exec_()
                            self.lblreg.hide()

                            a = Admin()
                            result = a.sign_up(u_name, f_name, l_name, password, mail)
                            if result == 1:
                                self.signup.destroy()
                            else:
                                self.lblnotreg.clear()
                                self.txtuser.clear()
                                loop = QEventLoop()
                                QTimer.singleShot(1000, loop.quit)
                                loop.exec_()
                                self.lblnotreg.hide()

                        except Exception as error:
                            print(error)

                else:
                    self.lblnotpass.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblnotpass.hide()
            else:
                if l_name == '' or f_name == '' or mail == '' or password == '' or con_pass == '' or v_username == '':
                    self.lblnotcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblnotcomp.hide()
                else:
                    if v_username == 0:
                        self.txtuser.clear()
                    if v_mail == 0:
                        self.txtmail.clear()
                    if v_f_name == 0:
                        self.txtFirst.clear()
                    if v_l_name == 0:
                        self.txtLast.clear()
                    self.lblnotreg.show()
                    loop = QEventLoop()
                    QTimer.singleShot(3000, loop.quit)
                    loop.exec_()
                    self.lblnotreg.hide()
        except Exception as error:
            print(error)
        else:
            pass

class UiAdditems(object):

    def __init__(self):
        self.additems = QtWidgets.QDialog()
        UiAdditems.setupUi(self, self.additems)
        self.additems.show()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        Dialog.setMaximumSize(1008, 583)
        Dialog.setMinimumSize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label.setStyleSheet("background-image: url(Images/bg.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.gbinsert = QtWidgets.QGroupBox(Dialog)
        self.gbinsert.setGeometry(QtCore.QRect(240, 40, 541, 491))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.gbinsert.setFont(font)
        self.gbinsert.setStyleSheet("QGroupBox{\n"
"background-color:rgb(197, 210, 255);\n"
"border:3px solid darkblue;\n"
"}\n"
"")
        self.gbinsert.setTitle("")
        self.gbinsert.setObjectName("gbinsert")
        self.lblname = QtWidgets.QLabel(self.gbinsert)
        self.lblname.setGeometry(QtCore.QRect(100, 90, 81, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblname.setFont(font)
        self.lblname.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblname.setObjectName("lblname")
        self.lbldesc = QtWidgets.QLabel(self.gbinsert)
        self.lbldesc.setGeometry(QtCore.QRect(100, 130, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lbldesc.setFont(font)
        self.lbldesc.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lbldesc.setObjectName("lbldesc")
        self.lblcost = QtWidgets.QLabel(self.gbinsert)
        self.lblcost.setGeometry(QtCore.QRect(100, 170, 81, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblcost.setFont(font)
        self.lblcost.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblcost.setObjectName("lblcost")
        self.txtname = QtWidgets.QLineEdit(self.gbinsert)
        self.txtname.setGeometry(QtCore.QRect(220, 80, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtname.setFont(font)
        self.txtname.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtname.setObjectName("txtname")
        self.txtdesc = QtWidgets.QLineEdit(self.gbinsert)
        self.txtdesc.setGeometry(QtCore.QRect(220, 120, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtdesc.setFont(font)
        self.txtdesc.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtdesc.setObjectName("txtdesc")
        self.txtcost = QtWidgets.QLineEdit(self.gbinsert)
        self.txtcost.setGeometry(QtCore.QRect(220, 160, 241, 31))
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.txtcost.setFont(font)
        self.txtcost.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtcost.setObjectName("txtcost")
        self.txtsell = QtWidgets.QLineEdit(self.gbinsert)
        self.txtsell.setGeometry(QtCore.QRect(220, 200, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtsell.setFont(font)
        self.txtsell.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}\n"
"")
        self.txtsell.setObjectName("txtsell")
        self.lblsell = QtWidgets.QLabel(self.gbinsert)
        self.lblsell.setGeometry(QtCore.QRect(100, 210, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblsell.setFont(font)
        self.lblsell.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblsell.setObjectName("lblsell")
        self.btnRefresh = QtWidgets.QPushButton(self.gbinsert)
        self.btnRefresh.setGeometry(QtCore.QRect(490, 570, 75, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnRefresh.setFont(font)
        self.btnRefresh.setToolTipDuration(2)
        self.btnRefresh.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.btnRefresh.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnRefresh.setAutoRepeat(False)
        self.btnRefresh.setDefault(False)
        self.btnRefresh.setFlat(False)
        self.btnRefresh.setObjectName("btnRefresh")
        self.label_3 = QtWidgets.QLabel(self.gbinsert)
        self.label_3.setGeometry(QtCore.QRect(200, 30, 131, 21))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setUnderline(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.label_3.setObjectName("label_3")
        self.lblamount = QtWidgets.QLabel(self.gbinsert)
        self.lblamount.setGeometry(QtCore.QRect(100, 250, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblamount.setFont(font)
        self.lblamount.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblamount.setObjectName("lblamount")
        self.lblSupp = QtWidgets.QLabel(self.gbinsert)
        self.lblSupp.setGeometry(QtCore.QRect(100, 290, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblSupp.setFont(font)
        self.lblSupp.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblSupp.setObjectName("lblSupp")
        self.lblCompany = QtWidgets.QLabel(self.gbinsert)
        self.lblCompany.setGeometry(QtCore.QRect(100, 330, 101, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblCompany.setFont(font)
        self.lblCompany.setStyleSheet("QLabel{\n"
"color:black;\n"
"}")
        self.lblCompany.setObjectName("lblCompany")
        self.txtSupp = QtWidgets.QLineEdit(self.gbinsert)
        self.txtSupp.setGeometry(QtCore.QRect(220, 280, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtSupp.setFont(font)
        self.txtSupp.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtSupp.setObjectName("txtSupp")
        self.txtCompany = QtWidgets.QLineEdit(self.gbinsert)
        self.txtCompany.setGeometry(QtCore.QRect(220, 320, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtCompany.setFont(font)
        self.txtCompany.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtCompany.setObjectName("txtCompany")
        self.txtamount = QtWidgets.QLineEdit(self.gbinsert)
        self.txtamount.setGeometry(QtCore.QRect(220, 240, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtamount.setFont(font)
        self.txtamount.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtamount.setObjectName("txtamount")
        self.lblcomp = QtWidgets.QLabel(self.gbinsert)
        self.lblcomp.setGeometry(QtCore.QRect(220, 370, 111, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblcomp.setFont(font)
        self.lblcomp.hide()
        self.lblcomp.setStyleSheet("QLabel{\n"
"color:darkblue;\n"
"}")
        self.lblcomp.setObjectName("lblcomp")
        self.groupBox = QtWidgets.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(350, 440, 311, 61))
        self.groupBox.setStyleSheet("QGroupBox{\n"
"border-radius:20px;\n"
"background:rgb(170, 170, 255);\n"
"border:2px solid darkblue;\n"
"}")
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.btnInsert = QtWidgets.QPushButton(self.groupBox)
        self.btnInsert.setGeometry(QtCore.QRect(30, 20, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnInsert.setFont(font)
        self.btnInsert.clicked.connect(lambda : UiAdditems.insert(self))
        self.btnInsert.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnInsert.setObjectName("btnInsert")
        self.btnExit = QtWidgets.QPushButton(self.groupBox)
        self.btnExit.setGeometry(QtCore.QRect(180, 20, 101, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.btnExit.setFont(font)
        self.btnExit.clicked.connect(lambda :self.additems.destroy())
        self.btnExit.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnExit.setObjectName("btnExit")
        self.lblnot = QtWidgets.QLabel(self.gbinsert)
        self.lblnot.setGeometry(QtCore.QRect(170, 370, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblnot.setFont(font)
        self.lblnot.setStyleSheet("QLabel{\n"
                                  "color:red;\n"
                                  "}")
        self.lblnot.setObjectName("lblcomp")
        self.lblnot.hide()
        self.lblnotval = QtWidgets.QLabel(self.gbinsert)
        self.lblnotval.setGeometry(QtCore.QRect(170, 370, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.lblnotval.setFont(font)
        self.lblnotval.setStyleSheet("QLabel{\n"
                                     "color:red;\n"
                                     "}")
        self.lblnotval.setObjectName("lblcomp")
        self.lblnotval.hide()

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Add Item"))
        self.lblname.setText(_translate("Dialog", "Product:"))
        self.lbldesc.setText(_translate("Dialog", "Description:"))
        self.lblcost.setText(_translate("Dialog", "Cost Price:"))
        self.txtname.setPlaceholderText(_translate("Dialog", "Enter Name"))
        self.txtdesc.setPlaceholderText(_translate("Dialog", "Enter Description"))
        self.txtcost.setPlaceholderText(_translate("Dialog", "Enter Cost Price"))
        self.txtsell.setPlaceholderText(_translate("Dialog", "Enter Selling Price"))
        self.lblsell.setText(_translate("Dialog", "Selling Price:"))
        self.btnRefresh.setToolTip(_translate("Dialog", "Load Latest Data"))
        self.btnRefresh.setText(_translate("Dialog", "Refresh"))
        self.label_3.setText(_translate("Dialog", "Add Items"))
        self.lblamount.setText(_translate("Dialog", "Amount:"))
        self.lblSupp.setText(_translate("Dialog", "Supplier:"))
        self.lblCompany.setText(_translate("Dialog", "Company:"))
        self.txtSupp.setPlaceholderText(_translate("Dialog", "Enter Supplier"))
        self.txtCompany.setPlaceholderText(_translate("Dialog", "Enter Company "))
        self.txtamount.setPlaceholderText(_translate("Dialog", "Enter Amount"))
        self.lblcomp.setText(_translate("Dialog", "Complete!"))
        self.btnInsert.setText(_translate("Dialog", "Insert "))
        self.btnExit.setText(_translate("Dialog", "Exit"))
        self.lblnot.setText(_translate("Dialog", "Please Fill All Fields"))
        self.lblnotval.setText(_translate("Dialog", "Incorrect Values"))

    def insert(self):
        name = self.txtname.text()
        desc = self.txtdesc.text()
        cp = self.txtcost.text()
        sp = self.txtsell.text()
        amount = self.txtamount.text()
        supplier = self.txtSupp.text()
        company = self.txtCompany.text()
        if name == '' or desc == '' or cp == '' or sp == '' or amount == '' or supplier == '' \
                or company == '':
            self.lblnot.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblnot.hide()
        else:
            name_v = Validation.name(name)
            amount_v = Validation.amount(amount)
            cp_v = Validation.amount(cp)
            sp_v = Validation.amount(sp)
            supplier_v = Validation.name(supplier)
            company_v = Validation.name(company)
            if name_v == 1 and amount_v == 1 and cp_v == 1 and supplier_v == 1 and company_v == 1 and sp_v == 1:
                a = Purchase()
                result = a.insert(name, desc, amount, cp, sp,supplier,company)
                if result == 1:
                    self.lblcomp.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblcomp.hide()
                else:
                    self.lblnotval.show()
                    loop = QEventLoop()
                    QTimer.singleShot(1000, loop.quit)
                    loop.exec_()
                    self.lblnotval.hide()

            else:
                self.lblnotval.show()
                if name_v != 1:
                    self.txtname.clear()
                if amount_v != 1:
                    self.txtamount.clear()
                if cp_v != 1:
                    self.txtcost.clear()
                if sp_v != 1:
                    self.txtsell.clear()
                if supplier_v != 1:
                    self.txtSupp.clear()
                if company_v != 1:
                    self.txtCompany.clear()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.lblnotval.hide()


class UiBill(object):
    """This class is used to display bill to customer
    the driver of this class wil ve called from Main.Bill.bill_name()
    method"""

    def __init__(self, name=None, product=None, amount=None,price=None, total=None):
        self.name = name
        self.product = product
        self.amount = amount
        self.price = price
        self.name = name
        self.total = total
        self.sum = 0
        for i in self.total:
            self.sum += int(i)
        self.Bill = QtWidgets.QDialog()
        UiBill.setupUi(self, self.Bill)
        self.Bill.show()

    def setupUi(self, UiBill):
        UiBill.setObjectName("UiBill")
        UiBill.resize(221, 406)
        self.listProductName = QtWidgets.QListWidget(UiBill)
        self.listProductName.setGeometry(QtCore.QRect(10, 70, 61, 192))
        self.listProductName.setObjectName("listProductName")
        self.listPrice = QtWidgets.QListWidget(UiBill)
        self.listPrice.setGeometry(QtCore.QRect(130, 70, 31, 192))
        self.listPrice.setObjectName("listPrice")
        self.label = QtWidgets.QLabel(UiBill)
        self.label.setGeometry(QtCore.QRect(30, 50, 51, 16))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(UiBill)
        self.label_2.setGeometry(QtCore.QRect(80, 50, 47, 13))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(UiBill)
        self.label_3.setGeometry(QtCore.QRect(130, 50, 47, 13))
        self.label_3.setObjectName("label_3")
        self.listTotal = QtWidgets.QListWidget(UiBill)
        self.listTotal.setGeometry(QtCore.QRect(170, 70, 31, 192))
        self.listTotal.setObjectName("listTotal")
        self.label_4 = QtWidgets.QLabel(UiBill)
        self.label_4.setGeometry(QtCore.QRect(170, 50, 47, 13))
        self.label_4.setObjectName("label_4")
        self.textFinalbill = QtWidgets.QPlainTextEdit(UiBill)
        self.textFinalbill.setGeometry(QtCore.QRect(10, 290, 201, 71))
        self.textFinalbill.setObjectName("textFinalbill")
        self.line = QtWidgets.QFrame(UiBill)
        self.line.setGeometry(QtCore.QRect(-20, 270, 241, 16))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.label_5 = QtWidgets.QLabel(UiBill)
        self.label_5.setGeometry(QtCore.QRect(60, 20, 111, 21))
        self.label_5.setStyleSheet("font: 14pt \"MS Shell Dlg 2\";")
        self.label_5.setObjectName("label_5")
        self.listAmount = QtWidgets.QListWidget(UiBill)
        self.listAmount.setGeometry(QtCore.QRect(80, 70, 41, 192))
        self.listAmount.setObjectName("listAmount")
        self.buttonloaddata = QtWidgets.QPushButton(UiBill)
        self.buttonloaddata.setGeometry(QtCore.QRect(54, 370, 111, 23))
        self.buttonloaddata.setObjectName("buttonloaddata")
        self.buttonloaddata.clicked.connect(lambda: self.Bill.destroy())

        self.retranslateUi(UiBill)
        QtCore.QMetaObject.connectSlotsByName(UiBill)

    def retranslateUi(self, UiBill):
        self.now = datetime.now()
        time = self.now.strftime("%I :%M :%S :%p")
        date = self.now.strftime("%d ,%B ,%Y")
        _translate = QtCore.QCoreApplication.translate
        UiBill.setWindowTitle(_translate("UiBill", "Dialog"))
        self.label.setText(_translate("UiBill", "Name"))
        self.label_2.setText(_translate("UiBill", "Amount"))
        self.label_3.setText(_translate("UiBill", "Price"))
        self.label_4.setText(_translate("UiBill", "Total"))
        self.textFinalbill.setPlainText(_translate("UiBill", "Name:  """+ self.name+""  '\n'""
"Total:  """+ str(self.sum)+""'PKR\n'""
"Date: """+date+""'\n'""
"Time: """+time+""'\n'""))
        self.label_5.setText(_translate("UiBill", "Super Mart "))
        self.buttonloaddata.setText(_translate("UiBill", "Exit"))
        for i in self.product:
            self.listProductName.addItem(i)
        for i in self.price:
            self.listPrice.addItem(i)
        for i in self.amount:
            self.listAmount.addItem(i)
        for i in self.total:
            self.listTotal.addItem(i)


class UiViewItems(object):

    def __init__(self):
        """Window of the Viewitems """
        self.viewitems = QtWidgets.QDialog()
        UiViewItems.setupUi(self, self.viewitems)
        self.viewitems.show()


    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        Dialog.setMaximumSize(1008, 583)
        Dialog.setMinimumSize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, -10, 1041, 604))
        self.label.setStyleSheet("background-image: url(Images/bg.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.groupBox = QtWidgets.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(35, 40, 941, 501))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet("QGroupBox{\n"
                                    "background-color:rgb(197, 210, 255);\n"
                                    "border:3px solid darkblue;\n"
                                    "}\n"
                                    "")
        self.groupBox.setAlignment(QtCore.Qt.AlignLeading | QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        self.groupBox.setObjectName("groupBox")
        self.tableWidget = QtWidgets.QTableWidget(self.groupBox)
        self.tableWidget.setGeometry(QtCore.QRect(20, 100, 901, 341))
        self.tableWidget.setStyleSheet("")
        self.tableWidget.setColumnCount(9)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        item.setFont(font)
        item.setBackground(QtGui.QColor(22, 13, 117))
        self.tableWidget.setHorizontalHeaderItem(0, item)
        self.tableWidget.setAlternatingRowColors(True)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        item.setBackground(QtGui.QColor(0, 0, 2))
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(10)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(8, item)
        self.groupBox_2 = QtWidgets.QGroupBox(self.groupBox)
        self.groupBox_2.setGeometry(QtCore.QRect(100, 30, 671, 51))
        self.groupBox_2.setStyleSheet("QGroupBox{\n"
                                      "border-radius:20px;\n"
                                      "background:rgb(170, 170, 255);\n"
                                      "border:2px solid darkblue;\n"
                                      "}")
        self.groupBox_2.setTitle("")
        self.groupBox_2.setObjectName("groupBox_2")
        self.btnrshow = QtWidgets.QPushButton(self.groupBox_2)
        self.btnrshow.setGeometry(QtCore.QRect(520, 20, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnrshow.setFont(font)
        self.btnrshow.setStyleSheet("QPushButton{\n"
                                    "background-color: rgb(36, 96, 167);\n"
                                    "color: rgb(255, 255, 255);\n"
                                    "border-radius:10px;\n"
                                    "}\n"
                                    "QPushButton:hover\n"
                                    "{\n"
                                    "background:#0094ff;\n"
                                    "text-transform:uppercase;\n"
                                    "}")
        self.btnrshow.setObjectName("btnrshow")
        self.btnrshow.clicked.connect(lambda: UiViewItems.display(self))
        self.btnsearch = QtWidgets.QPushButton(self.groupBox_2)
        self.btnsearch.setGeometry(QtCore.QRect(420, 20, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnsearch.setFont(font)
        self.btnsearch.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"

                                     "}")
        self.btnsearch.setObjectName("btnInsert")
        self.lbkname = QtWidgets.QLabel(self.groupBox_2)
        self.lbkname.setGeometry(QtCore.QRect(70, 20, 61, 16))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.lbkname.setFont(font)
        self.lbkname.setObjectName("lbkname")
        self.txtname = QtWidgets.QLineEdit(self.groupBox_2)
        self.txtname.setGeometry(QtCore.QRect(140, 20, 241, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtname.setFont(font)
        self.txtname.setStyleSheet("QLineEdit{\n"
                                   "border-radius:10px;\n"
                                   "border:1px solid black;\n"
                                   "}")
        self.txtname.setObjectName("txtname")
        self.lblComplete = QtWidgets.QLabel(self.groupBox)
        self.lblComplete.setGeometry(QtCore.QRect(380, 450, 111, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblComplete.setFont(font)
        self.lblComplete.setStyleSheet("QLabel{\n"
                                       "color: rgb(0, 0, 127);\n"
                                       "}")
        self.lblComplete.setObjectName("lblComplete")
        self.lblComplete.hide()

        self.lblbotfound = QtWidgets.QLabel(self.groupBox)
        self.lblbotfound.setGeometry(QtCore.QRect(380, 450, 190, 31))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lblbotfound.setFont(font)
        self.lblbotfound.setStyleSheet("QLabel{\n"
                                       "color:red;\n"
                                       "}")
        self.lblbotfound.setObjectName("lblComplete")
        self.lblbotfound.hide()
        self.btnExit = QtWidgets.QPushButton(self.groupBox)
        self.btnExit.setGeometry(QtCore.QRect(820, 450, 91, 21))
        self.btnExit.clicked.connect(lambda: self.viewitems.destroy())
        font = QtGui.QFont()
        font.setPointSize(11)
        self.btnExit.setFont(font)
        self.btnExit.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}")
        self.btnExit.setObjectName("btnExit")
        self.btnsearch.clicked.connect(lambda: UiViewItems.search_display(self))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "View Items"))
        self.groupBox.setTitle(_translate("Dialog", "View Items"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("Dialog", "Product ID"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("Dialog", "Name"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("Dialog", "Description"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("Dialog", "Amount"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("Dialog", "Cost Price"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("Dialog", "Selling Price"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("Dialog", "Supplier"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("Dialog", "Company"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("Dialog", "Purchase Date"))
        self.btnrshow.setText(_translate("Dialog", "Show All"))
        self.btnsearch.setText(_translate("Dialog", "Search"))
        self.lbkname.setText(_translate("Dialog", "Name:"))
        self.lblComplete.setText(_translate("Dialog", "Complete!"))
        self.btnExit.setText(_translate("Dialog", "Exit"))
        self.lblbotfound.setText(_translate("Dialog", "Item Not Found"))

    def display(self):
        try:
            ob = Purchase()
            result = ob.all()
            self.tableWidget.setRowCount(0)
            for row, form in enumerate(result):
                self.tableWidget.insertRow(row)
                for column, item in enumerate(form):
                    self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
            self.lblComplete.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblComplete.hide()
            self.txtname.clear()
        except Exception as error:
            print(error)

    def search_display(self):
        ob = Purchase()

        result = ob.by_name(self.txtname.text())
        if result == 0:
            self.tableWidget.setRowCount(0)
            self.lblbotfound.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblbotfound.hide()
            self.txtname.clear()

        else:
            self.tableWidget.setRowCount(0)
            for row, form in enumerate(result):
                self.tableWidget.insertRow(row)
                for column, item in enumerate(form):
                    self.tableWidget.setItem(row, column, QtWidgets.QTableWidgetItem(str(item)))
            self.lblComplete.show()
            loop = QEventLoop()
            QTimer.singleShot(1000, loop.quit)
            loop.exec_()
            self.lblComplete.hide()


class UiMain(object):

    def __init__(self,username):
        self.username = username
        self.main = QtWidgets.QDialog()
        UiMain.setupUi(self, self.main)
        self.main.show()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1008, 583)
        Dialog.setMaximumSize(1008, 583)
        Dialog.setMinimumSize(1008, 583)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-10, 0, 1021, 601))
        self.label.setStyleSheet("background-image: url(Images/bg.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(420, -10, 191, 51))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_7.setFont(font)
        self.label_7.setStyleSheet("QLabel{\n"
                                   "color:white;\n"
                                   "}")
        self.label_7.setObjectName("label_7")
        self.frame = QtWidgets.QFrame(Dialog)
        self.frame.setGeometry(QtCore.QRect(820, 50, 181, 511))
        self.frame.setStyleSheet("QFrame{\n"
                                 "background: black;\n"
                                 "border: 2px solid white;\n"
                                 "}")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label_4 = QtWidgets.QLabel(self.frame)
        self.label_4.setGeometry(QtCore.QRect(10, 10, 161, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setUnderline(True)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("QLabel{\n"
                                   "color:white;\n"
                                   "background:black;\n"
                                   "}")
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")
        self.btnSign = QtWidgets.QPushButton(self.frame)
        self.btnSign.setGeometry(QtCore.QRect(10, 200, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.btnSign.setFont(font)
        self.btnSign.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}\n"
                                   "")
        self.btnSign.setObjectName("btnSign")
        self.btnchpass = QtWidgets.QPushButton(self.frame)
        self.btnchpass.setGeometry(QtCore.QRect(10, 250, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.btnchpass.setFont(font)
        self.btnchpass.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}\n"
                                     "")
        self.btnchpass.setObjectName("btnchpass")
        self.btnLogout = QtWidgets.QPushButton(self.frame)
        self.btnLogout.setGeometry(QtCore.QRect(10, 400, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnLogout.setFont(font)
        self.btnLogout.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "color:tomato;\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}")
        self.btnLogout.setObjectName("btnLogout")
        self.btnActivity = QtWidgets.QPushButton(self.frame)
        self.btnActivity.setGeometry(QtCore.QRect(10, 300, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.btnActivity.setFont(font)
        self.btnActivity.setStyleSheet("QPushButton{\n"
                                       "background-color: rgb(36, 96, 167);\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius:10px;\n"
                                       "}\n"
                                       "QPushButton:hover\n"
                                       "{\n"
                                       "background:#0094ff;\n"
                                       "text-transform:uppercase;\n"
                                       "}\n"
                                       "")
        self.btnActivity.setObjectName("btnActivity")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setGeometry(QtCore.QRect(30, 50, 121, 81))
        self.label_3.setStyleSheet("image :url(Images/login.png);\n"
                                   "border: black;\n"
                                   "padding-top:10px;")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.lblUser = QtWidgets.QLabel(self.frame)
        self.lblUser.setGeometry(QtCore.QRect(40, 150, 121, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblUser.setFont(font)
        self.lblUser.setStyleSheet("QLabel{\n"
                                   "color: white;\n"
                                   "border:black;\n"
                                   "}")
        self.lblUser.setObjectName("lblUser")
        self.label_9 = QtWidgets.QLabel(self.frame)
        self.label_9.setGeometry(QtCore.QRect(16, 160, 16, 16))
        self.label_9.setStyleSheet("border:black;\n"
                                   "image: url(Images/dot.png);")
        self.label_9.setText("")
        self.label_9.setObjectName("label_9")
        self.btnDelAcc = QtWidgets.QPushButton(self.frame)
        self.btnDelAcc.setGeometry(QtCore.QRect(10, 350, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.btnDelAcc.setFont(font)
        self.btnDelAcc.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}\n"
                                     "")
        self.btnDelAcc.setObjectName("btnDelAcc")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(200, -40, 611, 651))
        self.label_2.setStyleSheet("QLabel{\n"
                                   "image: url(Images/supermarket-banner.png);\n"
                                   "}\n"
                                   "QLabel{\n"
                                   # "filter: drop-shadow(30px 10px 4px #4444dd);\n"
                                   "}")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.frame_2 = QtWidgets.QFrame(Dialog)
        self.frame_2.setGeometry(QtCore.QRect(10, 50, 181, 211))
        self.frame_2.setStyleSheet("QFrame{\n"
                                   "background: black;\n"
                                   "border: 2px solid white;\n"
                                   "}")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.label_5 = QtWidgets.QLabel(self.frame_2)
        self.label_5.setGeometry(QtCore.QRect(10, 10, 161, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setUnderline(True)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("QLabel{\n"
                                   "color:white;\n"
                                   "background:black;\n"
                                   "}")
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setObjectName("label_5")
        self.btnadd = QtWidgets.QPushButton(self.frame_2)
        self.btnadd.setGeometry(QtCore.QRect(10, 50, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnadd.setFont(font)
        self.btnadd.setStyleSheet("QPushButton{\n"
                                  "background-color: rgb(36, 96, 167);\n"
                                  "color: rgb(255, 255, 255);\n"
                                  "border-radius:10px;\n"
                                  "}\n"
                                  "QPushButton:hover\n"
                                  "{\n"
                                  "background:#0094ff;\n"
                                  "text-transform:uppercase;\n"
                                  "}\n"
                                  "\n"
                                  "")
        self.btnadd.setObjectName("btnadd")
        self.btnview = QtWidgets.QPushButton(self.frame_2)
        self.btnview.setGeometry(QtCore.QRect(10, 100, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnview.setFont(font)
        self.btnview.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}\n"
                                   "")
        self.btnview.setObjectName("btnview")
        self.btnEdit = QtWidgets.QPushButton(self.frame_2)
        self.btnEdit.setGeometry(QtCore.QRect(10, 150, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnEdit.setFont(font)
        self.btnEdit.setStyleSheet("QPushButton{\n"
                                   "background-color: rgb(36, 96, 167);\n"
                                   "color: rgb(255, 255, 255);\n"
                                   "border-radius:10px;\n"
                                   "}\n"
                                   "QPushButton:hover\n"
                                   "{\n"
                                   "background:#0094ff;\n"
                                   "text-transform:uppercase;\n"
                                   "}\n"
                                   "")
        self.btnEdit.setObjectName("btnEdit")
        self.frame_3 = QtWidgets.QFrame(Dialog)
        self.frame_3.setGeometry(QtCore.QRect(10, 270, 181, 301))
        self.frame_3.setStyleSheet("QFrame{\n"
                                   "background: black;\n"
                                   "border: 2px solid white;\n"
                                   "}")
        self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_3.setObjectName("frame_3")
        self.label_6 = QtWidgets.QLabel(self.frame_3)
        self.label_6.setGeometry(QtCore.QRect(10, 10, 161, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setUnderline(True)
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("QLabel{\n"
                                   "color:white;\n"
                                   "background:black;\n"
                                   "}")
        self.label_6.setAlignment(QtCore.Qt.AlignCenter)
        self.label_6.setObjectName("label_6")
        self.bnAddS = QtWidgets.QPushButton(self.frame_3)
        self.bnAddS.setGeometry(QtCore.QRect(10, 50, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.bnAddS.setFont(font)
        self.bnAddS.setStyleSheet("QPushButton{\n"
                                  "background-color: rgb(36, 96, 167);\n"
                                  "color: rgb(255, 255, 255);\n"
                                  "border-radius:10px;\n"
                                  "}\n"
                                  "QPushButton:hover\n"
                                  "{\n"
                                  "background:#0094ff;\n"
                                  "text-transform:uppercase;\n"
                                  "}")
        self.bnAddS.setObjectName("bnAddS")
        self.btnViewS = QtWidgets.QPushButton(self.frame_3)
        self.btnViewS.setGeometry(QtCore.QRect(10, 100, 161, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnViewS.setFont(font)
        self.btnViewS.setStyleSheet("QPushButton{\n"
                                    "background-color: rgb(36, 96, 167);\n"
                                    "color: rgb(255, 255, 255);\n"
                                    "border-radius:10px;\n"
                                    "}\n"
                                    "QPushButton:hover\n"
                                    "{\n"
                                    "background:#0094ff;\n"
                                    "text-transform:uppercase;\n"
                                    "}\n"
                                    "")
        self.btnViewS.setObjectName("btnViewS")
        self.btnadd.clicked.connect(lambda: UiMain.add_items(self))
        self.btnchpass.clicked.connect(lambda : UiMain.change_pass(self))
        self.btnLogout.clicked.connect(lambda: UiMain.log_out(self))
        self.btnview.clicked.connect(lambda: UiMain.viewitems(self))
        self.btnEdit.clicked.connect(lambda: UiMain.edit_items(self))
        self.btnViewS.clicked.connect(lambda: UiMain.viewsale(self))
        self.bnAddS.clicked.connect(lambda:UiMain.sale(self))
        self.btnSign.clicked.connect(lambda: UiMain.sign_up(self))
        self.btnActivity.clicked.connect(lambda: UiViewAcitvity())
        self.btnDelAcc.clicked.connect(lambda: UiMain.delete_admin(self))
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_7.setText(_translate("Dialog", "Main Window"))
        self.label_4.setText(_translate("Dialog", "Controls"))
        self.btnSign.setText(_translate("Dialog", "SignUp"))
        self.btnchpass.setText(_translate("Dialog", "Change Password"))
        self.btnLogout.setText(_translate("Dialog", "Log Out"))
        self.btnActivity.setText(_translate("Dialog", "View Activity"))
        self.lblUser.setText(_translate("Dialog", self.username))
        self.btnDelAcc.setText(_translate("Dialog", "Delete Account"))
        self.label_5.setText(_translate("Dialog", "Purchase"))
        self.btnadd.setText(_translate("Dialog", "Add Item"))
        self.btnview.setText(_translate("Dialog", "View Item"))
        self.btnEdit.setText(_translate("Dialog", "Edit Item"))
        self.label_6.setText(_translate("Dialog", "Sale"))
        self.bnAddS.setText(_translate("Dialog", "Sales"))
        self.btnViewS.setText(_translate("Dialog", "View Sales"))

    def delete_admin(self):
        """Call delte Admin window"""
        self.delete_obj = UiDeleteAdmin()

    def sale(self):
        """calls sale window"""
        self.sale_obj = UiSale()

    def change_pass(self):
        """Call change passoword class"""
        self.changepass_obj = UiChangePassword()

    def edit_items(self):
        """Calls edit items"""
        self.edititem_obj = UiEditItems()

    def sign_up(self):
        """Calls signup class"""
        self.signup_obj = UiSignUp()

    def viewsale(self):
        """Calls view sale class"""
        self.viewsale = UiViewSale()

    def viewitems(self):
        """Called when View items button is clicked
        shich calls the entire view items window"""
        self.viewitems_obj = UiViewItems()

    def add_items(self):
        """Calls the add items widnow when the
        add items button is clicked"""
        self.add_items_obj = UiAdditems()

    def log_out(self):

        aa = Admin()
        aa.log_out(self.username)
        self.a = UiHome()
        self.a.back()
        self.main.destroy()


class UiHome(object):

    def start(self):
        app = QtWidgets.QApplication(sys.argv)
        self.Home = QtWidgets.QDialog()
        UiHome.setupUi(self, self.Home)
        self.Home.show()
        sys.exit(app.exec_())

    def back(self):
        self.Home = QtWidgets.QDialog()
        UiHome.setupUi(self, self.Home)
        self.Home.show()

    def setupUi(self, Dialog):
        #self.setWindowIcon(QtGui.QIcon('icon.png'))
        #self.setWindowIcon(QtGui.QIcon('icon.png'))
        Dialog.setObjectName("Dialog")
        Dialog.resize(1108, 581)
        Dialog.setMaximumSize(1108, 581)
        Dialog.setMinimumSize(1108, 581)

        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(-100, -20, 1411, 601))
        self.label.setStyleSheet("background-image: url(Images/produce.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.groupBox_2 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(320, 140, 461, 341))
        self.groupBox_2.setStyleSheet("QGroupBox{\n"
                                      "border-radius:100px;\n"
                                      "background-color: rgba(0, 0, 0,0.7);\n"
                                      "}")
        self.groupBox_2.setTitle("")
        self.groupBox_2.setObjectName("groupBox_2")
        self.label_5 = QtWidgets.QLabel(self.groupBox_2)
        self.label_5.setGeometry(QtCore.QRect(100, 40, 281, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("QLabel{\n"
                                   "color:white;\n"
                                   "\n"
                                   "}")
        self.label_5.setObjectName("label_5")
        self.btnLogin_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.btnLogin_2.setGeometry(QtCore.QRect(170, 110, 131, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnLogin_2.setFont(font)
        self.btnLogin_2.setStyleSheet("QPushButton{\n"
                                      "background-color: rgb(36, 96, 167);\n"
                                      "color: rgb(255, 255, 255);\n"
                                      "border-radius:10px;\n"
                                      "}\n"
                                      "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}\n"
                                      "")
        self.btnLogin_2.setObjectName("btnLogin_2")
        self.btnaboutus_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.btnaboutus_2.setGeometry(QtCore.QRect(170, 180, 131, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnaboutus_2.setFont(font)
        self.btnaboutus_2.setStyleSheet("QPushButton{\n"
                                        "background-color: rgb(36, 96, 167);\n"
                                        "color: rgb(255, 255, 255);\n"
                                        "border-radius:10px;\n"
                                        "}\n"
                                        "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "}\n"
                                        "")
        self.btnaboutus_2.setObjectName("btnaboutus_2")
        self.btnExit_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.btnExit_2.setGeometry(QtCore.QRect(170, 250, 131, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.btnExit_2.setFont(font)
        self.btnExit_2.setStyleSheet("QPushButton{\n"
                                     "background-color: rgb(36, 96, 167);\n"
                                     "color: rgb(255, 255, 255);\n"
                                     "border-radius:10px;\n"
                                     "}\n"
                                     "QPushButton:hover\n"
                                     "{\n"
                                     "background:#0094ff;\n"
                                     "text-transform:uppercase;\n"
                                     "color:tomato;\n"
                                     "}\n"
                                     "")
        self.btnExit_2.setObjectName("btnExit_2")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(300, 20, 541, 51))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_7.setFont(font)
        self.label_7.setStyleSheet("QLabel{\n"
                                   "color:white;\n"
                                   "}")
        self.label_7.setObjectName("label_7")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(470, 90, 161, 91))
        self.label_2.setStyleSheet("image:url(Images/home-150499_640.png)")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.btnLogin_2.clicked.connect(lambda: UiHome.click(self))
        self.btnaboutus_2.clicked.connect(lambda: UiHome.about(self))
        self.btnExit_2.clicked.connect(lambda: sys.exit())
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_5.setText(_translate("Dialog", "Choose one of the following"))
        self.btnLogin_2.setText(_translate("Dialog", "Login"))
        self.btnaboutus_2.setText(_translate("Dialog", "About Us"))
        self.btnExit_2.setText(_translate("Dialog", "Exit"))
        self.label_7.setText(_translate("Dialog", "Welcome to Store Management System"))



    def about(self):
        self.obj_about = aboutus.Webpage()

    def click(self):
        self.Home.destroy()
        self.ui = UiLogin()

    def open_main(self,username):
        self.obj_main = UiMain(username)


class UiLogin(object):

    def __init__(self):
        self.Login = QtWidgets.QDialog()
        UiLogin.setupUi(self, self.Login)
        self.Login.show()

    def __del__(self):
        pass


    def setupUi(self, Login):             #Login Body
        Login.setObjectName("Login")
        Login.resize(449, 555)
        Login.setMaximumSize(449,555)
        Login.setStyleSheet("QDialog{\n"
"background-color: rgb(197, 210, 255);\n"
"}")
        self.label_3 = QtWidgets.QLabel(Login)
        self.label_3.setGeometry(QtCore.QRect(150, 10, 141, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(18)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("Qlabel{\n"
"font-color:rgb(255, 255, 255)\n"
"}")
        self.label_3.setObjectName("label_3")
        self.label_2 = QtWidgets.QLabel(Login)
        self.label_2.setGeometry(QtCore.QRect(20, 70, 350, 21))
        font = QtGui.QFont()
        font.setPointSize(13)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_2.setStyleSheet("QLabel{\n"
"color:darkblue\n"
"}")
        self.lblUser = QtWidgets.QLabel(Login)
        self.lblUser.setGeometry(QtCore.QRect(70, 220, 81, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblUser.setFont(font)
        self.lblUser.setObjectName("lblUser")
        self.lblPass = QtWidgets.QLabel(Login)
        self.lblPass.setGeometry(QtCore.QRect(70, 290, 91, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblPass.setFont(font)
        self.lblPass.setObjectName("lblPass")
        self.txtUser = QtWidgets.QLineEdit(Login)
        self.txtUser.setGeometry(QtCore.QRect(180, 220, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtUser.setFont(font)
        self.txtUser.setStyleSheet("QLineEdit{\n"
"border-radius:0px;\n"
"background-color: rgb(197, 210, 255);\n"
"border-bottom:1.5px solid black;\n"
"}")
        self.txtUser.setObjectName("txtUser")
        self.txtPass = QtWidgets.QLineEdit(Login)
        self.txtPass.setGeometry(QtCore.QRect(180, 280, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtPass.setFont(font)
        self.txtPass.setStyleSheet("QLineEdit{\n"
"border-radius:0px;\n"
                                   
"background-color: rgb(197, 210, 255);\n"
"border-bottom:2px solid black;\n"
"}")
        self.txtPass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtPass.setObjectName("txtPass")
        self.btnlogin = QtWidgets.QPushButton(Login)
        self.btnlogin.setGeometry(QtCore.QRect(60, 380, 331, 51))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.btnlogin.setFont(font)
        self.btnlogin.setStyleSheet("QPushButton{\n"                 
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnlogin.setObjectName("btnlogin")
        self.btnlogin.clicked.connect(lambda:UiLogin.on_click(self))
        QToolTip.setFont(QFont('SansSerif', 10))
        self.forgetpass = QtWidgets.QCommandLinkButton(Login)
        self.forgetpass.setGeometry(QtCore.QRect(160, 450, 141, 41))
        self.forgetpass.clicked.connect(lambda: UiLogin.on_click_forgetpass(self))
        self.forgetpass.setStyleSheet("QCommandLinkButton{\n"
"color:darkblue;\n"
"}")
        self.forgetpass.setObjectName("forgetpass")
        self.label = QtWidgets.QLabel(Login)
        self.label.setGeometry(QtCore.QRect(160, 100, 121, 91))
        self.label.setStyleSheet("image: url(Images/login-user-icon.png);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_4 = QtWidgets.QLabel(Login)
        self.label_4.setGeometry(QtCore.QRect(130, 330, 231, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("QLabel{\n"
"color: rgb(0, 0, 127);\n"
"}")
        self.label_4.setObjectName("label_4")                    #Login successfully
        self.label_4.hide()                                      #Hide Login successfully label

        self.label_5 = QtWidgets.QLabel(Login)
        self.label_5.setGeometry(QtCore.QRect(90, 330, 270, 50))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("QLabel{\n"
                                   "color: red;\n"
                                   "}")
        self.label_5.setObjectName("label_5")  # Login successfully
        self.label_5.hide()  # Hide Login successfully label
        self.label_6 = QtWidgets.QLabel(Login)
        self.label_6.setGeometry(QtCore.QRect(140, 330, 270, 50))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("QLabel{\n"
                                   "color: red;\n"
                               "}")
        self.label_6.setObjectName("label_5")  # Login successfully
        self.label_6.hide()  # Hide Login successfully label
        self.retranslateUi(Login)
        QtCore.QMetaObject.connectSlotsByName(Login)

    def retranslateUi(self, Login):

        _translate = QtCore.QCoreApplication.translate
        Login.setWindowTitle(_translate("Login", "Login"))
        self.label_3.setText(_translate("Login", "Login Form"))
        self.label_2.setText(_translate("Login", "Enter your username and password to log on:"))
        self.lblUser.setText(_translate("Login", "<strong>Username:</strong>"))
        self.lblPass.setText(_translate("Login", "<strong>Password:</strong>"))
        self.btnlogin.setText(_translate("Login", "Login"))
        self.forgetpass.setText(_translate("Login", "Forget Password?"))
        self.label_4.setText(_translate("Login", "Successfully Login!"))
        self.label_5.setText(_translate("Login", "Invalid Username OR Password"))
        self.label_6.setText(_translate("Login", "Please Fill both fields"))
        self.txtUser.setPlaceholderText("Enter username")
        self.txtPass.setPlaceholderText("Enter Password")

    def on_click(self):
        """This will show that the person is successfully
        Login after login button is clicked"""
        password = self.txtPass.text()
        username = self.txtUser.text()
        if password != '' and username != '':
            obj = Admin()
            result = (obj.log_in(username, password))
            if result == 1:
                self.label_4.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_4.hide()
                # Call Main Window and destroy the home pages and login page
                a = UiHome()
                a.open_main(username)
                self.Login.close()
            else:
                self.label_5.show()
                self.txtPass.clear()
                self.txtUser.clear()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_5.hide()
        else:
            self.txtUser.clear()
            self.txtPass.clear()
            self.label_6.show()
            loop = QEventLoop()
            QTimer.singleShot(2000, loop.quit)
            loop.exec_()
            self.label_6.hide()

    def on_click_forgetpass(self):
        self.ui = UiForgetPassword()
        self.Login.destroy()


class UiForgetPassword(object):

    def __init__(self):
        try:
            self.ForgetPassword = QtWidgets.QDialog()
            UiForgetPassword.setupUi(self, self.ForgetPassword)
            self.ForgetPassword.show()
        except Exception as error:
            print(error)


    def setupUi(self, ForgetPassword):
        ForgetPassword.setObjectName("ForgetPassword")
        ForgetPassword.resize(449, 567)
        ForgetPassword.setStyleSheet("QDialog{\n"
"background-color: rgb(197, 210, 255);\n"
"}")
        self.label_3 = QtWidgets.QLabel(ForgetPassword)
        self.label_3.setGeometry(QtCore.QRect(140, 10, 211, 41))
        font = QFont()
        font.setFamily("Halvatica")
        font.setPointSize(18)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("Qlabel{\n"
"font-color:rgb(255, 255, 255)\n"
"}")
        self.label_3.setObjectName("label_3")
        self.label_2 = QtWidgets.QLabel(ForgetPassword)
        self.label_2.setGeometry(QtCore.QRect(20, 90, 350, 21))
        self.label_2.setStyleSheet("QLabel{\n"
"color:darkblue\n""}")
        font = QtGui.QFont()
        font.setPointSize(13)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.lblUser = QtWidgets.QLabel(ForgetPassword)
        self.lblUser.setGeometry(QtCore.QRect(60, 270, 81, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblUser.setFont(font)
        self.lblUser.setObjectName("lblUser")
        self.lblCode = QtWidgets.QLabel(ForgetPassword)
        self.lblCode.setGeometry(QtCore.QRect(60, 340, 121, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lblCode.setFont(font)
        self.lblCode.setObjectName("lblCode")
        self.txtcode = QtWidgets.QLineEdit(ForgetPassword)
        self.txtcode.setGeometry(QtCore.QRect(200, 330, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtcode.setFont(font)
        self.txtcode.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtcode.setMaxLength(6)
        self.txtcode.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtcode.setObjectName("txtcode")
        self.btnSubmit = QtWidgets.QPushButton(ForgetPassword)
        self.btnSubmit.setGeometry(QtCore.QRect(60, 430, 331, 51))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.btnSubmit.setFont(font)
        self.btnSubmit.setStyleSheet("QPushButton{\n"
"background-color: rgb(36, 96, 167);\n"
"color: rgb(255, 255, 255);\n"
"border-radius:10px;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"background:#0094ff;\n"
"text-transform:uppercase;\n"
"}")
        self.btnSubmit.setObjectName("btnSubmit")
        self.btnSubmit.clicked.connect(lambda: self.forget)
        self.label = QtWidgets.QLabel(ForgetPassword)
        self.label.setGeometry(QtCore.QRect(130, 110, 191, 161))
        self.label.setStyleSheet("image: url(Images/forgetpass.png);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.txtuser = QtWidgets.QLineEdit(ForgetPassword)
        self.txtuser.setGeometry(QtCore.QRect(200, 270, 191, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.txtuser.setFont(font)
        self.txtuser.setStyleSheet("QLineEdit{\n"
"border-radius:10px;\n"
"}")
        self.txtuser.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.txtuser.setObjectName("txtuser")
        self.label_4 = QtWidgets.QLabel(ForgetPassword)
        self.label_4.setGeometry(QtCore.QRect(80, 380, 300, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("QLabel{\n"
"color:darkblue;\n"
"}\n"
"")
        self.label_4.setAlignment(QtCore.Qt.AlignBottom|QtCore.Qt.AlignHCenter)
        self.label_4.setObjectName("label_4")
        self.label_4.hide()
        self.label_5 = QtWidgets.QLabel(ForgetPassword)
        self.label_5.setGeometry(QtCore.QRect(90, 380, 280, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_5.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_5.setObjectName("label_5")
        self.label_5.hide()
        self.label_6 = QtWidgets.QLabel(ForgetPassword)
        self.label_6.setGeometry(QtCore.QRect(90, 380, 280, 31))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("QLabel{\n"
                                   "color:red;\n"
                                   "}\n"
                                   "")
        self.label_6.setAlignment(QtCore.Qt.AlignBottom | QtCore.Qt.AlignHCenter)
        self.label_6.setObjectName("label_6")
        self.label_6.hide()
        self.btnLogin = QtWidgets.QPushButton(ForgetPassword)
        self.btnLogin.setGeometry(QtCore.QRect(60, 500, 331, 51))
        self.btnLogin.clicked.connect(lambda: [UiForgetPassword.go_to_Login(self)])
        font = QtGui.QFont()
        font.setPointSize(14)
        self.btnLogin.setFont(font)
        self.btnLogin.setStyleSheet("QPushButton{\n"
                                    "background-color: rgb(36, 96, 167);\n"
                                    "color: rgb(255, 255, 255);\n"
                                    "border-radius:10px;\n"
                                    "}\n"
                                    "QPushButton:hover\n"
                                    "{\n"
                                    "background:#0094ff;\n"
                                    "text-transform:uppercase;\n"
                                    "}")
        self.btnLogin.setObjectName("btnLogin")
        self.btnSubmit.clicked.connect(lambda: UiForgetPassword.forget(self))
        self.btnLogin.setToolTip('<h5>Go To login page </h5>')
        self.retranslateUi(ForgetPassword)
        QtCore.QMetaObject.connectSlotsByName(ForgetPassword)

    def retranslateUi(self, ForgetPassword):
        _translate = QtCore.QCoreApplication.translate
        ForgetPassword.setWindowTitle(_translate("ForgetPassword", "ForgetPassword"))
        self.label_3.setText(_translate("ForgetPassword", "Forget Password"))
        self.label_2.setText(_translate("ForgetPassword", "Enter your username and code:"))
        self.lblUser.setText(_translate("ForgetPassword", "Username:"))
        self.lblCode.setText(_translate("ForgetPassword", "Recovery Code:"))
        self.txtcode.setPlaceholderText(_translate("ForgetPassword", "6 digit pin"))
        self.btnSubmit.setText(_translate("ForgetPassword", "Submit"))
        self.txtuser.setPlaceholderText(_translate("ForgetPassword", "Enter Username:"))
        self.label_4.setText(_translate("ForgetPassword", "Check Email and Go To Log In"))
        self.label_5.setText(_translate("ForgetPassword", "Invalid username or code"))
        self.label_6.setText(_translate("ForgetPassword", "Please fill Both fields"))
        self.btnLogin.setText(_translate("ForgetPassword", "Go To Login"))

    def go_to_Login(self):
        ui = UiLogin()
        self.ForgetPassword.destroy()

    def forget(self):
        """this method is called when
        submit button is click"""
        username = self.txtuser.text()
        code = self.txtcode.text()
        a = Admin()
        result = a.forgot_pass(username, code)
        if result == 0:
            if username == '' or code == '':
                self.label_6.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_6.hide()
            else:

                self.label_5.show()
                loop = QEventLoop()
                QTimer.singleShot(1000, loop.quit)
                loop.exec_()
                self.label_5.hide()
                self.txtcode.clear()
                self.txtuser.clear()

        else:
            mail = Email(result[-1], result[4] + ' ' + result[3], result[1])
            mail.mail_recovery(result[2])
            self.label_4.show()
            loop = QEventLoop()
            QTimer.singleShot(2000, loop.quit)
            loop.exec_()
            self.label_4.hide()


if __name__ == "__main__":
    obj = UiHome()
    obj.start()