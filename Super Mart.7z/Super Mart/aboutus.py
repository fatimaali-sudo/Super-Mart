import webbrowser


class Webpage(object):

	def __init__(self):

		webbrowser.open("index.html", new=0, autoraise=True)

if __name__ == "__main__":Webpage()