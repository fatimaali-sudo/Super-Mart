<----------------------INSTRUCTIONS-------------------->
Before running the befor make sure the following things
->You have added all those environment varables properply.
->You must an active internet connection.
->You must run all database qureries.
->One admin must be these which is already present in the datbase file.
->Make sure you have Pyqt5 and Pyqt5-tools installed on your machine.
->For checking open the mail "super.mart.project@gmail.com" foer confirmation of the working of the email module.


For converting into executeable run the setup.py file from the command prompt.You can edit configrations from the setup.py file according to you own desires.


<--------------------End-------------------------------->