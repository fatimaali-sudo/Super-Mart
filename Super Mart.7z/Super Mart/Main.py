import re
import smtplib
from email.message import EmailMessage
import math
import random
import pymysql as MYSQLdb #if you have mysql installed then comment this line and uncomment the next line
#import MYSQLdb
import os
from datetime import datetime
from smtplib import SMTPException


class Employee(object):
    """Used for interacting with the
    Employee Table present in the daa base"""

    def __init__(self):
        self.__db = MYSQLdb.connect('localhost', os.getenv('db_user'), os.getenv('db_pass'), 'super_mart')
        self.__cursor = self.__db.cursor()



    def insert(self, name, address, gender, designation, salary):
        """Used to insert values in the Employee table"""
        val = name, address, gender, designation, salary
        sql = """insert into employee(emp_name, address, gender, designation, salary) VALUES (%s,%s,%s,%s,%s)"""
        try:
            self.__cursor.execute(sql, val)
            self.__db.commit()
            return "Employee Added Successfully"
        except Exception as error:
            self.__db.rollback()
            return error

    def promote(self, name, designation, salary):
        """when an employee will be promoted this method will
        be executed"""
        val = designation, salary, name
        sql = """select emp_id from employee where EMP_NAME=%s"""
        try:
            self.__cursor.execute(sql, name,)
            result = self.__cursor.fetchall()
            if len(result) == 0:
                return "Employee Does Not Exist"
            else:
                sql = """update Employee set DESIGNATION=%s , SALARY=%s WHERE EMP_NAME=%s"""
                try:
                    self.__cursor.execute(sql, val)
                    self.__db.commit()
                    return "Promotion Successful"
                except Exception as error:
                    self.__db.rollback()
                    return error
                finally:
                    pass
        except Exception as error:
            return error

    def delete(self, name):
        """Used to delete an Employee from the database"""
        sql = """select emp_id from employee where EMP_NAME=%s"""
        try:
            self.__cursor.execute(sql, name,)
            result = self.__cursor.fetchall()
            if len(result) == 0:
                return "Employee Not Found"
            else:
                sql = """delete from employee where EMP_NAME =%s"""
                try:
                    self.__cursor.execute(sql, name,)
                    self.__db.commit()
                    return "Employee deleted Successfully"
                except Exception as error:
                    return error
                finally:
                    pass
        except Exception as error:
            self.__db.rollback()
            return error

    def __del__(self):
        self.__db.close()


class Purchase:
    """ This class used for the interaction of of table name 'Purchase
    when we purchase items many parameters are passed here according to the need
    '"""
    def __init__(self):
        """Establishes a connection with the database"""
        self.db = MYSQLdb.connect("localhost", os.getenv('db_user'), os.getenv('db_pass'), "super_mart")
        self.cursor = self.db.cursor()

    def insert(self, name, info, amount, cost_price, sale_price,supplier, company):
        """Used to insert Values into TAble purchase"""
        now = datetime.now()
        time = now.strftime("%d ,%B ,%Y")
        sql = """insert into Purchase(name, description, Amount, cost,SALE_PRICE,Supplier,Company , purchase_date)
         VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"""
        val = name, info, amount, cost_price, int(sale_price), supplier ,company ,time
        try:
            self.cursor.execute(sql, val)
            self.db.commit()
        except Exception as error:
            self.db.rollback()
            return error
        else:
            return True

    def set_purchase(self, product_id, cost, sale):
        """in order to update cost and sale price"""
        sql = """update Purchase set COST=%s,SALE_PRICE =%s  where product_id=%s"""
        val = cost, sale, product_id
        try:
            self.cursor.execute(sql, val)
            self.db.commit()
            return True
        except Exception as error:
            self.db.rollback()
            return error

    def by_name(self, name):
        """returns all rows having the product name"""
        sql = """select * from purchase where NAME=%s"""
        self.cursor.execute(sql, name,)
        result = self.cursor.fetchall()
        if len(result) > 0:
            return result
        else:
            try:
                if name == '':
                    return False
                else:
                    sql = """select * from purchase where NAME like %s """
                    self.cursor.execute(sql,('%' + name + '%',))
                    result = self.cursor.fetchall()
            except Exception as error:
                print(error)
            else:
                if len(result) > 0:
                    return result
                else:
                    return False

    def all(self):

        """returns all rows in the puchase table"""
        sql = """select * from purchase"""
        self.cursor.execute(sql)
        result = self.cursor.fetchall()
        return result

    def __del__(self):
        self.db.close()

    def purchase(self, p_id, quantity, customer):
        """Takes name of the product a, and quantity
        and returns out of stock if required quantity is not available"""
        sql = """select Amount from purchase where product_id=%s"""
        val = p_id,
        try:
            self.cursor.execute(sql, val)
            old_quantity = self.cursor.fetchall()
            new_quantity = old_quantity[0][0] - int(quantity)
            if int(new_quantity) < 0:
                """If the quantity is not available then result
                 the result will be will return 2"""
                return 2
            else:
                sql = """update purchase set Amount=%s where product_id=%s"""
                val = new_quantity, p_id
                try:
                    self.cursor.execute(sql, val)
                    self.db.commit()
                    sql = """select product_id,NAME,SALE_PRICE from purchase where product_id = %s"""
                    self.cursor.execute(sql, p_id ,)
                    result = self.cursor.fetchall()
                    ob1 = Sales()
                    return ob1.sale(result[0][0],result[0][1], quantity, result[0][2],customer )

                except Exception as error:
                    self.db.rollback()
                    return error
        except Exception as error:
            return error


class Sales:
    """This class will aggregated with Purchase"""
    def __init__(self):
        """Establish a connection with the database to used
        in the whole class """
        self.db = MYSQLdb.connect("localhost", os.getenv('db_user'), os.getenv('db_pass'), "super_mart")
        self.cursor = self.db.cursor()

    def sale( self, sold_items, name, quantity, sale_price, customer):
        """This method inserts the data into the Sales table when a product is purchased"""
        now = datetime.now()
        sql = """insert into sale(sold_items,ProductName,QUANTITY, SALE_PRICE,Customer, sale_date) 
        VALUES (%s,%s,%s,%s,%s,%s)"""
        val = sold_items, name, quantity, sale_price, customer, now.strftime("%d ,%B ,%Y")
        print(val)
        try:
            self.cursor.execute(sql, val)
            self.db.commit()
            return True
        except Exception as error:
            error = error
            print(error)

            self.db.rollback()
            return False

    def get_all(self):
        sql = """select * from sale"""
        self.cursor.execute(sql)
        result = self.cursor.fetchall()
        return result

    def search_pname(self, p_name):
        sql = """select * from sale where ProductName=%s"""
        self.cursor.execute(sql, p_name,)
        result = self.cursor.fetchall()
        if result == 0:
            return False
        else:
            return result

    def search_orderid(self, order_id):
        sql = """select * from sale where order_no=%s"""
        self.cursor.execute(sql, order_id, )
        result = self.cursor.fetchall()
        if result == 0:
            return False
        else:
            return result

    def search_customer(self, customer):
        sql = """select * from sale where Customer=%s"""
        self.cursor.execute(sql, customer.title(), )
        result = self.cursor.fetchall()
        if result == 0:
            return False
        else:
            return result

    def bill(self, customer):
        try:
            sql = """select ProductName,QUANTITY,SALE_PRICE,sale_date from sale where Customer =%s"""
            self.cursor.execute(sql, customer,)
            result = self.cursor.fetchall()
            product = []
            amount = []
            price = []
            for i in range(len(result)):
                for j in range(len(result[i])):
                    if j == 0:
                        product.append(result[i][j])
                    if j == 1:
                        amount.append(result[i][j])
                    if j == 2:
                        price.append(result[i][j])
            total = []
            for i in range(len(product)):
                total.append(amount[i]*price[i])

            product_str = ','.join(product)
            price_str = ','.join(str(e) for e in amount)
            amount_str = ','.join(str(i) for i in price)
            total_str = ','.join(str(i) for i in total)
        except Exception as eror :
            print(eror)
        else:

            ob = Bill()
            result = (ob.insert(customer, product_str, price_str, amount_str, total_str))
            a = Bill()
            result = a.bill_name(customer)
            return result
        finally:
            pass

    def __del__(self):

        """Destructor closes connection"""
        self.db.close()


class Admin(object):

    """This class will be used to
    interact with the data base in fetching and
    updating Values from the Admin Table"""



    def __init__(self):
        """Establishes a connection that will be
        used all over the class"""
        try:
            self.db = MYSQLdb.connect("localhost", os.getenv('db_user'),os.getenv('db_pass'),"super_mart")
            self.cursor = self.db.cursor()
        except Exception as error:
            print(error)
            exit()
        else:
            pass


    def log_search_all(self):
        sql = """select I.LogInID as "Activity ID", I.username,I.TimeIn,O.TimeOut,I.Date
            from LogIn I join LogOut O on I.LogInID = O.LogOutId"""
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
        except Exception as error:
            print(error)
        else:
            return result

    def log_search_name(self, username):
        """For searching acti vity w.r.t username"""
        sql = """select I.LogInID as "Activity ID", I.username,I.TimeIn,O.TimeOut,I.Date
            from LogIn I join LogOut O on I.LogInID = O.LogOutId where I.username = %s"""
        try:
            self.cursor.execute(sql,username,)
            result = self.cursor.fetchall()
        except Exception as error:
            print(error)
        else:
            if len(result) > 0:
                return  result
            else:
                return None





    def log_out(self, username):
        now = datetime.now()
        """Called when a Admin Log in to the system"""
        sql = """insert into LogOut(username, Date , TimeOut) Values(%s,%s,%s)"""
        try:
            self.cursor.execute(sql, (username,now.strftime("%d %B,%Y"),now.strftime("%I :%M :%S :%p") ))
            self.db.commit()
        except Exception as error:
            print(error)
            self.db.rollback()
        else:
            return True
        finally:
            pass

    def log_on(self, username):

        """Called when a ADoim Log in to the system"""
        sql = """insert into LogIn(username, Date , TimeIn) Values(%s,%s,%s)"""

        now = datetime.now()
        try:
            self.cursor.execute(sql, (username,now.strftime("%d %B,%Y"),now.strftime("%I :%M :%S :%p")))
            self.db.commit()
        except Exception as error:
            print(error)
            self.db.rollback()
        else:
            return True
        finally:
            pass

    def update_pass(self, username,password, new_pass):
        """this method takes in username password and new password"""

        a = Admin.log_in(self, username, password)
        if a == 1:
            val = new_pass, username
            sql = """update Admin Set Password=%s where Username = %s"""
            try:
                self.cursor.execute(sql, val)
                self.db.commit()
            except Exception as error:
                self.db.rollback()
                return error
            else:
                return True
        else:
            return False

    def get_name(self, username):
        """In order to get all Attributes"""
        sql = """select First_name,Last_name from Admin WHERE Username=%s"""
        self.cursor.execute(sql, username,)
        result = self.cursor.fetchall()
        return result[0][0]+' '+result[0][1]

    def get_email(self, username):
        """To get Email address"""
        sql = """select Email from Admin WHERE Username=%s"""
        self.cursor.execute(sql, username, )
        result = self.cursor.fetchall()
        return result[0][0]

    def del_admin(self, username, password, email):
        """for deleting admin
        there is only one admin you cannot delete it
        returns the following for the works
        0. Cannot Log In
        1. Admin Deleted
        2. Cannot delete Admin"""
        if Admin.log_in(self, username, password) == 1:
            self.cursor.execute("select * from Admin")
            result = self.cursor.fetchall()
            if len(result) > 1:
                if username == 'admin':
                    obj = Email('talha.amir9225@gmail.com',"Talha Amir",'admin')
                    obj.delelte()

                    return 2
                else:
                    try:
                        sql = """select Admin_ID from Admin where username=%s and password=%s and Email=%s"""
                        self.cursor.execute(sql, (username, password, email))
                        get_id = self.cursor.fetchall()
                        sql = """delete from admin where admin_id =%s"""
                    except Exception as error:
                        print(error)
                    else:
                        try:
                            self.cursor.execute(sql, get_id,)
                            self.db.commit()
                        except Exception as error:
                            return False
                        else:
                            return True
            else:

                return 2
        else:
            return False

    def log_in(self, username, password):
        """In order to verify login username
         and password
         Will be used with the login button"""
        sql = """select Username,password from admin where Username=%s and password = %s"""
        val = username, password
        self.cursor.execute(sql, val)
        result = self.cursor.fetchall()
        if len(result) == 0:
            return False
        else:
            if result[0][0] == username and result[0][1] == password:
                Admin.log_on(self, username)
                return True
            else:
                return False

    def forgot_pass(self, username, code):
        """Check the code received and verifies it
        with the username
        Will be used with the forget password window
        This method a fill return a tuple of
        (True,Username,Password,First_name,Last_name,Email)
        If the recovery code is coorect"""
        sql = """select Username,Password,First_name,Last_name,Email from admin where Username = %s and code = %s"""
        val = username, code
        try:
            self.cursor.execute(sql, val)
            result = self.cursor.fetchall()
            if len(result) == 0:
                return False
            else:
                username, password, f_name, l_name, email = result[0][0], result[0][1], result[0][2], result[0][3],\
                                                            result[0][4]
                return True, username, password, f_name, l_name, email
        except Exception as error:
            return error

    def sign_up(self, username, f_name, l_name, password, email):
        """Adds an Admin to the Table
        Will be used with the sign up window"""
        mail_obj = Email(email, f_name + ' ' + l_name, username)
        code = mail_obj.mail()
        val = username, f_name, l_name, password, email, code
        sql = """insert into admin(username, first_name, last_name, password, email, code)
         values (%s,%s,%s,%s,%s,%s)"""
        try:
            self.cursor.execute(sql, val)
            self.db.commit()
        except Exception as error:
            self.db.rollback()
            return error
        else:
            return True

    def __del__(self):
        self.db.close()


class Email(object):
    """Takes an email ID for for receiving
    the 6-digit code sent by the Super Mart
    for recovery purpose of Admin Account"""

    def __init__(self, receiving, name, username):
        """Object must have the email of receiver
        and the full of the receiver"""

        self.username = username
        self.receiver = []
        self.receiver.append(receiving)
        self.email_id = os.environ.get('mart_id')
        self.id_pass = os.environ.get('mart_code')
        # Sending a copy of Code Generated to Admin
        self.receiver.append(self.email_id)
        self.name = name
        self.pin = Email.code()

    def pass_change(self):
        """This generates e mail when when a user changes
        the password"""
        message = EmailMessage()
        message['Subject'] = 'Password Changed'
        message['From'] = "Super Mart"
        # if there are more than one recipients we may have a list of recipients
        # Now for testing purpose i have sent email to my account for confirmation
        message['to'] = self.receiver
        message.set_content("Recovery main")
        message.add_alternative("""\
               <!DOCTYPE html>
                       <html>
                       <head>
                           <title>
                        </title>
                       </head>
                       <body>
                        <h1 style="color:black;">
                            Hello """ + self.name + """,<br>    </h1>

                            <h3>Your Request For change of password is approved, your password is succesfully updated. <br></h3>
                        <h4><strong>Username : """ + self.username + """</strong></h4>
                        <p>If this activity was not done by you please recover your account as soon as possible<p>

                        <p>Please keep Your password and username  safe and dont tell it to any one else.
                        This code  is confidential. 
                        It is strictly forbidden to share any part of this message with any third person.</p>

                       </body>
                       </html>
                       """, subtype='html')
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
                # Used to log in
            try:
                smtp.login(self.email_id, self.id_pass)
                # USed for sending mail
                smtp.send_message(message)
            except Exception as error:
                print(error)
            else:
                print(" ALL FINE")

    @staticmethod
    def code():
        """This method generates a code which is passes
        to the mail method for being sent to the receiver"""
        # Declare a digits variable
        # which stores all digits
        digits = "0123456789"
        code = ""
        # length of password can be chaged
        # by changing value in range
        for i in range(6):
            code += digits[math.floor(random.random() * 10)]
        return code

    def mail_recovery(self, password):
        """This method will mail the receiver his account details
        when he ask for recovery of the account"""
        # EmailMessage Class creates the structure of the Email
        message = EmailMessage()
        message['Subject'] = 'Recovery Request'
        message['From'] = "Super Mart"
        # if there are more than one recipients we may have a list of recipients
        # Now for testing purpose i have sent email to my account for confirmation
        message['to'] = self.receiver
        message.set_content("Recovery main")
        message.add_alternative("""\
        <!DOCTYPE html>
                <html>
                <head>
                    <title>
                	</title>
                </head>
                <body>
                	<h1 style="color:black;">
                		Hello """ + self.name + """,<br>    </h1>

                		<h5>You have requested for password recovery, <br></h5>
                	<h4><strong>Username : """ + self.username + """</strong></h4>
                	<h4> <strong>Password : """ + password + """</strong> <br></h4>
                	<h4>Now you can change your password from Contol Panel</h4>

                	<p>Please keep Your password and username  safe and dont tell it to any one else.
                	This code  is confidential. 
                	It is strictly forbidden to share any part of this message with any third person.</p>

                </body>
                </html>
                """, subtype='html')

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            # Used to log in
            try:
                smtp.login(self.email_id, self.id_pass)
                # USed for sending mail
                smtp.send_message(message)
            except Exception as error:
                print(error)

    def delelte(self):
        self.username = 'admin'
        self.receiver.append('talha.amir9225@gmail.com')
        self.name = "Talha Amir"

        """Cannot delete account for admin"""
        message = EmailMessage()
        message['Subject'] = 'Access Denied'
        message['From'] = "Super Mart"
        # if there are more than one recipients we may have a list of recipients
        # Now for testing purpose i have sent email to my account for confirmation
        message['to'] = self.receiver
        message.set_content("Recovery main")
        message.add_alternative("""\
        <!DOCTYPE html>
                <html>
                <head>
                    <title>
                	</title>
                </head>
                <body>
                	<h1 >
                		Hello """ + self.name + """,<br>    </h1>
                		<h4 style="color:red;">You cannot delete admin Account.</h4>

                </body>
                </html>
                """, subtype='html')

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            # Used to log in
            try:
                smtp.login(self.email_id, self.id_pass)
                # USed for sending mail
                smtp.send_message(message)
                return self.pin
            except Exception as error:
                print(error)

    def mail(self):
        # EmailMessage Class creates the structure of the Email
        message = EmailMessage()
        message['Subject'] = 'Sign Up Successful'
        message['From'] = "Super Mart"
        # if there are more than one recipients we may have a list of recipients
        # Now for testing purpose i have sent email to my account for confirmation
        message['to'] = self.receiver
        message.set_content("Recovery main")
        message.add_alternative("""\
<!DOCTYPE html>
        <html>
        <head>
            <title>
        	</title>
        </head>
        <body>
        	<h1 style="color:blue;">
        		Hello """ + self.name + """,<br>    </h1>

        		<h5>Your Email Security code is,<br></h5><h4> <strong>""" + self.pin + """</strong> <br></h4>
        	<p>Username : """+self.username+"""

        	<p>Please keep Your code safe and dont tell it to any one else.
        	This code  is confidential. 
        	It is strictly forbidden to share any part of this message with any third person.</p>

        </body>
        </html>
        """, subtype='html')

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            # Used to log in
            try:
                smtp.login(self.email_id, self.id_pass)
                # USed for sending mail
                smtp.send_message(message)
                return self.pin
            except Exception as error:
                print(error)


class Validation(object):

    """Static methods in Python are extremely similar to python class level methods,
    the difference being that a static method is bound to a class rather than the
    objects for that class.

    This means that a static method can be called without an object for that class.
     This also means that static methods cannot modify the state of an object as they
     are not bound to it."""

    """This class consist of method with names of the particular
    data a method a validates it consists of static methods"""
    @staticmethod
    def name(name):
        """Validated name like Fist Name or Last Name
        return a tuple at index 0 (bool Value) at index 1 (message)"""
        if re.findall(r'^[A-Z][a-z]{2,25}', name):
            return True
        else:
            return False

    @staticmethod
    def full_name(name):
        """Validate full nam
        return a tuple at index 0 (bool Value) at index 1 (message)"""
        if re.findall(r'^[A-Z][a-z]{2,25}\s[A-Z][a-z]{2,25}', name):
            return True
        else:
            return False

    @staticmethod
    def mail(mail):
        """validate e-mail whether enter email is correct or not
        return a tuple at index 0 (bool Value) at index 1 (message)"""
        if re.findall(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)", mail):
            return True
        else:
            return False

    @staticmethod
    def salary(salary):
        """The salary cannot be greater than 7 digits and smaller than 4 digits
        return a tuple at index 0 (bool Value) at index 1 (message)"""
        if re.findall(r'^[1-9][0-9]{4,7}$', str(salary)):

            return True
        else:
            return False

    @staticmethod
    def user_name(username):
        """It just verifies username is starting with
        alphabets
        """
        if re.findall(r'^[a-z]{3}.', username):
            return True
        else:
            return False

    @staticmethod
    def amount(amount):
        # TODO: Recheck and change this expression
        """IT just verifi es that amount is in complete
        integer"""
        if re.findall(r'^[0-9]+$', str(amount)):
            return True
        else:
            return False

class Bill:
    """Used to display all all data of class bill"""
    def __init__(self):
        self.__db = MYSQLdb.connect("localhost", os.getenv('db_user'), os.getenv('db_pass'), "super_mart")
        self.__cursor = self.__db.cursor()

    def insert(self, customer, product, price, amount, total):
        """insert data into salebill table"""
        sql = """insert into salebill(Customer, Product, Price, Amount, Total, Date) VALUES (%s,%s,%s,%s,%s,%s)"""
        now = datetime.now()
        val = (customer, product, price, amount, total,  now.strftime("%d ,%B ,%Y"))
        try:
            self.__cursor.execute(sql,val)
            self.__db.commit()
        except Exception as error:
            self.__db.rollback()
            error = error
            print(error)
            return False
        else:
            return True

    def bill_name(self, customer):
        """return a tuple at which following ar the inedexes sith their respective values
        0.Customer
        1.Product
        2.Amount
        3.Price
        4.Total
        """
        sql = """select Product,Amount,Price,Total from salebill where Customer = %s"""
        self.__cursor.execute(sql, customer, )
        result = self.__cursor.fetchall()
        product = ''
        amount = ''
        price = ''
        total = ''
        i = 0
        for j in range(len(result)):
            for i in range(len(result[i])):
                if i == 0:
                    product = result[j][i]
                if i == 1:
                    amount = result[j][i]
                if i == 2:
                    price = result[j][i]
                if i == 3:
                    total = result[j][i]
        product = product.split(',')
        price = price.split(',')
        amount = amount.split(',')
        total = total.split(',')
        return customer, product, price, amount, total


if __name__ == "__main__":
    a = Email('talha.amir9225@gmail.com',"Talha Amir",'admin')
    a.delelte()